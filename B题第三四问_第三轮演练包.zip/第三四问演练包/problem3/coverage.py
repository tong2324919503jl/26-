"""Complete discovery certificates, distinct from heuristic exploration scores."""
from __future__ import annotations

from functools import lru_cache
import json
from pathlib import Path
from math import cos, hypot, pi, sin, sqrt
from .geometry import cross, dist, distance_segment, hull, inside_convex


@lru_cache(maxsize=1)
def certified_ring():
    from .coverage_certificate import verify_certificate
    path = Path(__file__).resolve().parent.parent/"problem4/results/coverage_certificate.json"
    document = json.loads(path.read_text(encoding="utf-8"))
    if not verify_certificate(document):
        raise ValueError("第四问连续覆盖证书未通过精确复核")
    return tuple(tuple(p) for p in document["stations"])


def shortest_open_route(start, points):
    remaining, route = list(points), []
    current = start
    while remaining:
        index = min(range(len(remaining)), key=lambda i: dist(current, remaining[i]))
        current = remaining.pop(index)
        route.append(current)
    for _ in range(8):
        improved = False
        for i in range(len(route)-1):
            a = start if i == 0 else route[i-1]
            for j in range(i+1, len(route)):
                old, new = dist(a, route[i]), dist(a, route[j])
                if j+1 < len(route):
                    old += dist(route[j], route[j+1])
                    new += dist(route[i], route[j+1])
                if new < old-1e-6:
                    route[i:j+1] = reversed(route[i:j+1])
                    improved = True
        if not improved:
            break
    return route


@lru_cache(maxsize=4)
def coverage_design(problem):
    if problem == 3:
        return ((0.0, 0.0),) + tuple((1200*cos(k*pi/3), 1200*sin(k*pi/3)) for k in range(6)), ()
    step = 980.0
    def point(i, j):
        return (step*(i+j/2), step*sqrt(3)*j/2)
    triangles, vertices = [], set()
    for i in range(-6, 7):
        for j in range(-4, 5):
            a, b, c, d = point(i, j), point(i+1, j), point(i, j+1), point(i+1, j+1)
            for tri in ((a, b, c), (d, c, b)):
                intersects = (any(hypot(*p) <= 1800 for p in tri)
                              or inside_convex((0.0, 0.0), list(tri))
                              or any(distance_segment((0.0, 0.0), x, y) <= 1800
                                     for x, y in zip(tri, tri[1:]+tri[:1])))
                if intersects:
                    triangles.append(tri)
                    vertices.update(tri)
    return tuple(sorted(vertices, key=lambda p: (hypot(*p), p))), tuple(triangles)


@lru_cache(maxsize=4)
def heuristic_features(problem):
    # This grid only ranks search actions; it is never a stopping certificate.
    points = [(x, y) for x in range(-1800, 1801, 300)
              for y in range(-1800, 1801, 300) if hypot(x, y) <= 1800]
    if problem == 3:
        return tuple((x, y, 0, 0) for x, y in points)
    return tuple((x, y, cos(k*pi/4), sin(k*pi/4)) for x, y in points for k in range(8))


class Coverage:
    def __init__(self, problem, branch="baseline"):
        self.problem = problem
        self.anchors, self.triangles = coverage_design(problem)
        if problem == 4 and branch in ("efficient", "paired", "joint"):
            self.anchors, self.triangles = certified_ring(), ()
        self.positions = []
        self.visited = set()
        self.features = heuristic_features(problem)
        self.seen_mask = 0
        self.complete = False
        self.reason = ""
        self._masks = {}
        self._certified_triangles = set()

    def feature_mask(self, point):
        key = round(point[0], 5), round(point[1], 5)
        if key not in self._masks:
            bits = 0
            px, py = point
            for i, (x, y, ux, uy) in enumerate(self.features):
                dx, dy = px-x, py-y
                if dx*dx+dy*dy <= 980**2 and (self.problem == 3 or ux*dx+uy*dy >= 0):
                    bits |= 1 << i
            self._masks[key] = bits
        return self._masks[key]

    def gain(self, point):
        return (self.feature_mask(point) & ~self.seen_mask).bit_count() / len(self.features)

    def add(self, point):
        if any(dist(point, p) < 1e-6 for p in self.positions):
            return
        self.positions.append(point)
        self.seen_mask |= self.feature_mask(point)
        for i, anchor in enumerate(self.anchors):
            if dist(point, anchor) < 1e-6:
                self.visited.add(i)
        if len(self.visited) == len(self.anchors):
            self.complete, self.reason = True, "all_guaranteed_cover_stations_scanned"
        elif self.problem == 3 and len(self.positions) >= 5:
            if self._omni_certificate():
                self.complete, self.reason = True, "continuous_disk_cover_certificate"
        elif self.problem == 4 and self.triangles and len(self.positions) >= 6:
            for i, tri in enumerate(self.triangles):
                if i in self._certified_triangles:
                    continue
                nearby = [p for p in self.positions if max(dist(p, v) for v in tri) <= 999.999999]
                if len(nearby) >= 3:
                    h = hull(nearby)
                    if all(inside_convex(v, h, tolerance=1e-8) for v in tri):
                        self._certified_triangles.add(i)
            if len(self._certified_triangles) == len(self.triangles):
                self.complete, self.reason = True, "local_convex_hull_directional_certificate"

    def _omni_certificate(self):
        # Boxes intersecting the target disk are discarded only when one entire
        # box lies in a guaranteed reception disk. No sampled-point termination.
        rim = [(1800*cos(k*pi/24), 1800*sin(k*pi/24)) for k in range(48)]
        if any(all(dist(p, s) > 999.999 for s in self.positions) for p in rim):
            return False
        pending = [(-1800.0, -1800.0, 1800.0, 1800.0, 0)]
        while pending:
            x0, y0, x1, y1, depth = pending.pop()
            nearest_x = max(x0, min(0, x1))
            nearest_y = max(y0, min(0, y1))
            if hypot(nearest_x, nearest_y) > 1800:
                continue
            if any(max(abs(s[0]-x0), abs(s[0]-x1))**2
                   + max(abs(s[1]-y0), abs(s[1]-y1))**2 <= 999.999**2 for s in self.positions):
                continue
            if depth >= 8:
                return False
            xm, ym = (x0+x1)/2, (y0+y1)/2
            pending.extend((a, b, c, d, depth+1) for a, b, c, d in
                           ((x0,y0,xm,ym),(xm,y0,x1,ym),(x0,ym,xm,y1),(xm,ym,x1,y1)))
        return True

    def next_station(self, position, branch, unknown_count):
        pending = [p for i, p in enumerate(self.anchors) if i not in self.visited]
        if not pending:
            raise RuntimeError("Coverage plan exhausted without a certificate")
        if branch == "baseline":
            return min(pending, key=lambda p: dist(position, p))
        if branch in ("efficient", "paired", "joint"):
            return shortest_open_route(position, pending)[0]
        def rank(p):
            gain = self.gain(p)
            return (dist(position, p)/5 + unknown_count*6 + 20) / (0.04 + gain)
        return min(pending, key=rank)

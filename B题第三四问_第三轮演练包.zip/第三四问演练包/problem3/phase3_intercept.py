"""Interrupt a long trip to a search station when a new source is detected."""
from math import hypot,isfinite
from .geometry import dist
from .phase3_adaptive import AdaptivePolicy


class InterceptPolicy(AdaptivePolicy):
    def __init__(self,api,problem,parameters=None,step=450,radius=1600):
        if isinstance(step,bool) or not isinstance(step,(int,float)) or not isfinite(step) or step<=0:
            raise ValueError('Intercept step must be a finite positive number')
        super().__init__(api,problem,parameters,radius)
        self.intercept_step=step
        self.intercept_count=0

    def scan(self,position):
        p=self.api.position
        length=dist(p,position)
        if self.initial_annulus and length>1100 and hypot(*p)>1100:
            fraction=min(.55,self.intercept_step/length)
            q=(p[0]+fraction*(position[0]-p[0]),p[1]+fraction*(position[1]-p[1]))
            if self.coverage.gain(q)>.01:
                found=sum(t.known for t in self.tracks.values())
                super().scan(q)
                self.intercept_count+=1
                if sum(t.known for t in self.tracks.values())>found:
                    return
        super().scan(position)


def factory(api,problem,parameters=None,**options):
    return InterceptPolicy(api,problem,parameters,**options)

"""One optical clearance action at a time for thin disconnected enclosures.

Failed clearance disks are subtracted as inscribed convex polygons, retaining a
union of convex fragments. Optical selection is heuristic; a successful public
clear response is still required. The original radio/finite-sweep policy remains
available after a bounded number of optical actions.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import statistics
import time

from .phase3_route import RoutePolicy
from .phase3_localization import LocalizationPolicy
from .geometry import clip, covering_circle, diameter_pair, dist
from .protocol import Client, output_path
from .simulation import LocalWorld
from .cases import make_case


def area(polygon):
    return abs(sum(a[0]*b[1]-a[1]*b[0]for a,b in zip(polygon,polygon[1:]+polygon[:1])))/2


def subtract_failed_disk(polygon,center,radius=20.,sides=16):
    """Retain P minus an inner disk polygon as a union, without filling holes."""
    if not polygon:return []
    bound=(radius-.001)*math.cos(math.pi/sides)
    inside=list(polygon)
    outside=[]
    for k in range(sides):
        nx,ny=math.cos(2*math.pi*k/sides),math.sin(2*math.pi*k/sides)
        offset=nx*center[0]+ny*center[1]+bound
        piece=clip(inside,-nx,-ny,-offset)
        if piece:outside.append(piece)
        inside=clip(inside,nx,ny,offset)
        if not inside:break
    return outside


def bounding_strip(polygon):
    _,a,b=diameter_pair(polygon)
    length=dist(a,b)
    ux,uy=((b[0]-a[0])/length,(b[1]-a[1])/length)if length else(1.,0.)
    xy=[((p[0]-a[0])*ux+(p[1]-a[1])*uy,-(p[0]-a[0])*uy+(p[1]-a[1])*ux)for p in polygon]
    return a,(ux,uy),(min(p[0]for p in xy),max(p[0]for p in xy)),(min(p[1]for p in xy),max(p[1]for p in xy))


def fragment_centers(polygon):
    center,radius=covering_circle(polygon)
    if radius<=19.8:
        return [(center,area(polygon))]
    origin,(ux,uy),(xmin,xmax),(ymin,ymax)=bounding_strip(polygon)
    width=ymax-ymin
    if width>=39.6:return []
    spacing=2*math.sqrt(19.8**2-(width/2)**2)
    count=max(1,math.ceil((xmax-xmin)/spacing))
    if count>40:return []
    result=[]
    offset=ux*origin[0]+uy*origin[1]
    for i in range(count):
        low=xmin+(xmax-xmin)*i/count
        high=xmin+(xmax-xmin)*(i+1)/count
        piece=clip(clip(polygon,ux,uy,offset+high),-ux,-uy,-offset-low)
        if not piece:continue
        center,radius=covering_circle(piece)
        if radius>19.999:
            x,y=(low+high)/2,(ymin+ymax)/2
            center=(origin[0]+x*ux-y*uy,origin[1]+x*uy+y*ux)
        result.append((center,area(piece)))
    return result


def disk_mass_score(fragments,center):
    """Heuristic area score; clipping tolerances may overlap tiny boundaries."""
    total=0.
    bound=19.999*math.cos(math.pi/16)
    for fragment in fragments:
        if all(dist(p,center)<=bound for p in fragment):
            total+=area(fragment)
            continue
        piece=fragment
        for k in range(16):
            nx,ny=math.cos(2*math.pi*k/16),math.sin(2*math.pi*k/16)
            piece=clip(piece,nx,ny,nx*center[0]+ny*center[1]+bound)
            if not piece:break
        total+=area(piece)
    return total


class OpticalPolicy(RoutePolicy,LocalizationPolicy):
    def __init__(self,api,problem,parameters=None,max_length=200.,max_width=32.,optical_mode="nearest",route_variant="milestone"):
        super().__init__(api,problem,variant=route_variant,parameters=parameters)
        self.variant="negative"if problem==3 else"lookahead_pair"
        if problem==3:
            for t in self.tracks.values():t.omni_negatives=True
        self.optical_length=max_length
        self.optical_width=max_width
        self.optical_mode=optical_mode
        self.optical_counts={}
        self.optical_cache={}
        self.optical_fragment_peak=0

    def optical_candidates(self,track):
        if self.optical_length<=0 or track.near is not None or not track.failed_clears or not track.polygon:
            return []
        if self.optical_counts.get(track.channel,0)>=16:return []
        _,_,(lo,hi),(low,high)=bounding_strip(track.polygon)
        if hi-lo>self.optical_length or high-low>self.optical_width:return []
        signature=(tuple(track.polygon),tuple(track.failed_clears))
        cached=self.optical_cache.get(track.channel)
        if cached and cached[0]==signature:return cached[1]
        fragments=[track.polygon]
        for failed in track.failed_clears:
            pieces=[]
            for fragment in fragments:pieces.extend(subtract_failed_disk(fragment,failed))
            fragments=pieces
            if len(fragments)>200:
                self.optical_cache[track.channel]=(signature,[])
                return []
        self.optical_fragment_peak=max(self.optical_fragment_peak,len(fragments))
        candidates=[]
        for fragment in fragments:candidates.extend(fragment_centers(fragment))
        candidates=[(p,mass)for p,mass in candidates if all(dist(p,f)>3 for f in track.failed_clears)]
        if self.optical_mode=="unionmass":
            candidates=[(p,disk_mass_score(fragments,p))for p,_ in candidates]
        self.optical_cache[track.channel]=(signature,candidates)
        return candidates

    def optical_point(self,track):
        candidates=self.optical_candidates(track)
        if not candidates:return None
        if self.optical_mode in ("mass","unionmass"):
            return max(candidates,key=lambda row:max(1e-8,row[1])/(3.+dist(self.api.position,row[0])/5.))[0]
        return min(candidates,key=lambda row:dist(self.api.position,row[0]))[0]

    def event_point(self,track):
        point=self.optical_point(track)
        return point if point is not None else super().event_point(track)

    def next_step(self,track):
        point=self.optical_point(track)
        if point is not None:
            self.optical_counts[track.channel]=self.optical_counts.get(track.channel,0)+1
            self.clear(point,track)
            return
        return super().next_step(track)

    def run(self):
        result=super().run()
        result.update(optical_decision_actions=sum(self.optical_counts.values()),
                      optical_fragment_peak=self.optical_fragment_peak,
                      optical_length=self.optical_length,optical_width=self.optical_width,optical_mode=self.optical_mode)
        return result


def factory(api,problem,parameters=None,**options):
    return OpticalPolicy(api,problem,parameters=parameters,**options)


def evaluate(case,length,mode):
    root=Path(__file__).resolve().parent.parent
    params=json.loads((root/f"problem{case['problem']}/config.json").read_text(encoding="utf-8"))["parameters"]
    world=LocalWorld(case)
    api=Client(world.exchange,real_guard=False)
    policy=factory(api,case["problem"],parameters=params,max_length=length,optical_mode=mode)
    started=time.perf_counter()
    try:result=policy.run()
    except Exception as exc:result={"complete_certificate":False,"error":repr(exc)}
    metrics=world.final_metrics()
    return {"case":case["name"],"family":case["family"],"length":length,"mode":mode,
            **metrics,"policy":result,"complete":result["complete_certificate"]and metrics["source_count"]==metrics["cleared_count"],
            "average_time_s":metrics["virtual_time_s"]/max(1,metrics["cleared_count"]),"wall_time_s":time.perf_counter()-started}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--problem",type=int,choices=(3,4),required=True)
    parser.add_argument("--count",type=int,default=64)
    parser.add_argument("--lengths",nargs="+",type=float,default=[0.,100.,200.,400.])
    parser.add_argument("--modes",nargs="+",choices=("nearest","mass","unionmass"),default=["nearest","mass"])
    parser.add_argument("--split",default="train")
    parser.add_argument("--output",required=True)
    args=parser.parse_args()
    output=output_path(args.output)
    if output.exists():parser.error("Refusing overwrite")
    settings=[(l,m)for l in args.lengths for m in args.modes if l or m==args.modes[0]]
    rows=[]
    for i in range(args.count):
        case=make_case(args.problem,args.split,i)
        for length,mode in settings:rows.append(evaluate(case,length,mode))
        if(i+1)%8==0:
            print(json.dumps({"done":i+1,"means":{f"{l}_{m}":round(statistics.mean(r["average_time_s"]for r in rows if(r["length"],r["mode"])==(l,m)),3)for l,m in settings},"failures":sum(not r["complete"]for r in rows)}),flush=True)
    summary={f"{l}_{m}":{"cases":len(g),"complete":sum(r["complete"]for r in g),
              "mean_average_time_s":statistics.mean(r["average_time_s"]for r in g),
              "mean_distance_m":statistics.mean(r["distance_m"]for r in g),
              "mean_measures":statistics.mean(r["policy"].get("actions",{}).get("measure",0)for r in g),
              "mean_clears":statistics.mean(r["policy"].get("actions",{}).get("clear",0)for r in g),
              "mean_optical_decisions":statistics.mean(r["policy"].get("optical_decision_actions",0)for r in g),
              "max_wall_time_s":max(r["wall_time_s"]for r in g),
              "failures":[r["case"]for r in g if not r["complete"]]}
             for l,m in settings if(g:=[r for r in rows if(r["length"],r["mode"])==(l,m)])}
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps({"data_origin":"local_simulation_not_official","problem":args.problem,"split":args.split,"summary":summary,"rows":rows},ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(summary,ensure_ascii=False,indent=2))


if __name__=="__main__":main()

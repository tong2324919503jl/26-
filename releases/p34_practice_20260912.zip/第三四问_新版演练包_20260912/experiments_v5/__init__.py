"""Local research variants; no network or access to simulator truth."""

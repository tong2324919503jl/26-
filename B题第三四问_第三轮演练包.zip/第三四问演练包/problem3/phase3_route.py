"""Experimental receding-horizon route control, using only public feedback.

All search completion conditions are inherited from the existing certified plan.
The novel branch interleaves individual information actions and opportunistically
updates other known channels at positions already visited for another action.
"""
from __future__ import annotations

from math import atan2, degrees
import time

from .geometry import clip_bearing, covering_circle, dist
from .policy import Policy
from .protocol import BudgetExceeded
from .routing import portfolio_route


class RoutePolicy(Policy):
    def __init__(self, api, problem, variant="staged", parameters=None):
        super().__init__(api, problem, "portfolio", parameters=parameters)
        self.route_variant = variant
        self.step_counts = {}
        self.step_losses = {}
        self.opportunity_count = 0
        self.last_opportunity = {}

    def expected_gain(self, track, point):
        center, radius = track.circle()
        if not track.observations or radius < 35:
            return False
        if dist(point, track.observations[-1][0]) < 60:
            return False
        if dist(point, center) > 1100:
            return False
        if any(dist(point, p) < 1 for p in track.negative_positions):
            return False
        theta = degrees(atan2(center[1]-point[1], center[0]-point[0]))
        predicted = clip_bearing(track.polygon, point, theta)
        if not predicted:
            return False
        _, rnew = covering_circle(predicted)
        return rnew < min(75, 0.55*radius)

    def bystanders(self):
        if self.route_variant not in ("opportunity", "milestone"):
            return super().bystanders()
        point = self.api.position
        candidates = [t for t in self.known_pending() if self.expected_gain(t, point)]
        for track in candidates:
            if self.expected_gain(track, point):
                self.measure(point, track)
                self.opportunity_count += 1

    def next_step(self, track):
        channel = track.channel
        count = self.step_counts.get(channel, 0)
        losses = self.step_losses.get(channel, 0)
        self.step_counts[channel] = count + 1
        if track.near is not None or count >= 10 or losses >= 3 or track.geometry_resets:
            return super().localize(track)
        center, radius = track.circle()
        if radius <= self.parameters["clear_radius"] and not any(dist(center, p) < 3 for p in track.failed_clears):
            if self.clear(center, track):
                return
            if not any(dist(center, p) < 1e-6 for p, _ in track.observations):
                response = self.measure(center, track)
                self.step_losses[channel] = losses + (response["measure_result"] == "no_signal")
                return
        if self.problem == 4 and self.paired_probe(track) is not None:
            return
        point = self.probe(track, count, losses)
        response = self.measure(point, track)
        self.step_losses[channel] = losses + (response["measure_result"] == "no_signal")

    def event_point(self, track):
        if self.route_variant == "centroid" and track.near is None and len(track.polygon) >= 3:
            poly = track.polygon
            areas = [a[0]*b[1]-b[0]*a[1] for a,b in zip(poly, poly[1:]+poly[:1])]
            total = sum(areas)
            if abs(total) > 1e-9:
                return tuple(sum((a[j]+b[j])*w for a,b,w in zip(poly,poly[1:]+poly[:1],areas))/(3*total) for j in (0,1))
        if self.route_variant == "milestone" and track.near is None and track.circle()[1] > self.parameters["clear_radius"]:
            # The first information action is an actual prerequisite for an
            # uncertain source; selecting its centre alone underprices detours.
            return self.probe(track, self.step_counts.get(track.channel, 0), self.step_losses.get(track.channel, 0))
        return track.circle()[0]

    def run(self):
        started = time.perf_counter()
        if not self.api.entered:
            self.api.enter()
        complete = False
        try:
            self.scan((0.0, 0.0))
            while True:
                self.bystanders()
                known = self.known_pending()
                found_count = sum(t.known for t in self.tracks.values())
                if not known:
                    if len(self.api.cleared) == 16:
                        complete, self.reason = True, "population_upper_bound_16"
                        break
                    if self.coverage.complete:
                        complete, self.reason = True, self.coverage.reason
                        break
                events = [(self.event_point(t), t) for t in known]
                if not self.coverage.complete and self.unknown() and found_count < 16:
                    anchors = [p for i, p in enumerate(self.coverage.anchors) if i not in self.coverage.visited]
                    if self.route_variant in ("deferred", "deferred300", "deferred900"):
                        allowance = {"deferred": 600, "deferred300": 300, "deferred900": 900}[self.route_variant]
                        kept = []
                        for event, track in events:
                            center, radius = track.circle()
                            witnesses = [p for p in anchors if self.expected_gain(track, p)]
                            if not witnesses or min(dist(self.api.position,p)+dist(p,center)-dist(self.api.position,center) for p in witnesses) > allowance:
                                kept.append((event, track))
                        events = kept
                    events += [(p, None) for p in anchors]
                if not events:
                    raise RuntimeError("No event and no completion proof")
                self.warm_route = portfolio_route(self.api.position, [p for p,t in events], self.warm_route, self.parameters["route_starts"])
                first = self.warm_route[0]
                point, track = next(e for e in events if e[0] == first)
                if track is None:
                    self.scan(point)
                else:
                    self.next_step(track)
                    if track.channel in self.api.cleared and self.unknown() and found_count < 16:
                        if self.coverage.gain(self.api.position) >= self.parameters["scan_gain"]:
                            self.scan(self.api.position)
        except BudgetExceeded as exc:
            self.reason = str(exc)
        if not self.api.exited:
            try:
                self.api.exit()
            except BudgetExceeded:
                pass
        return {"problem": self.problem, "branch": "phase3_route_"+self.route_variant,
                "complete_certificate": complete, "stop_reason": self.reason,
                "virtual_time_s": self.api.virtual_time, "actions": dict(self.api.counts),
                "coverage_scan_stops": self.scan_stops, "optical_fallbacks": self.fallbacks,
                "geometry_resets": sum(t.geometry_resets for t in self.tracks.values()),
                "paired_radial_cuts": sum(t.paired_radial_cuts for t in self.tracks.values()),
                "opportunity_measures": self.opportunity_count,
                "policy_runtime_s": time.perf_counter()-started}


def factory(api, problem, parameters=None, route_variant="milestone", localization_variant=None):
    """Composable branch factory; no network access or simulator discovery."""
    if localization_variant is None:
        return RoutePolicy(api, problem, variant=route_variant, parameters=parameters)
    from .phase3_localization import LocalizationPolicy

    class Combined(RoutePolicy, LocalizationPolicy):
        def next_step(self, track):
            previous, self.phase = self.phase, "localize"
            try:
                return super().next_step(track)
            finally:
                self.phase = previous

    policy = Combined(api, problem, variant=route_variant, parameters=parameters)
    policy.variant = localization_variant
    if "negative" in localization_variant and problem == 3:
        for track in policy.tracks.values():
            track.omni_negatives = True
    return policy

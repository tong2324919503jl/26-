"""Frozen visibility/incremental localization plus geometric scan ordering."""
from experiments_v5.p4_discovery_route_global import GlobalDiscoveryMixin
from experiments_v5.p4_incremental_visibility import SearchPolicy as IncrementalVisibility


class SearchPolicy(GlobalDiscoveryMixin, IncrementalVisibility):
    algorithm_version = 'problem4_v5_incremental_visibility_discovery'
    discovery_mode = 'scan_savings'
    route_milestones = False

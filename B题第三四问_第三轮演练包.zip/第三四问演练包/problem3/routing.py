"""Multiple constructive routes, segment reversal, and node relocation."""
from .geometry import dist


def route_cost(start,route):
    return sum(dist(a,b)for a,b in zip([start]+route,route))


def improve(start,route):
    route=list(route)
    for _ in range(10):
        changed=False
        for i in range(len(route)-1):
            a=start if i==0 else route[i-1]
            for j in range(i+1,len(route)):
                old,new=dist(a,route[i]),dist(a,route[j])
                if j+1<len(route):
                    old+=dist(route[j],route[j+1])
                    new+=dist(route[i],route[j+1])
                if new<old-1e-6:
                    route[i:j+1]=reversed(route[i:j+1]);changed=True
        for i in range(len(route)):
            p=route[i];a=start if i==0 else route[i-1]
            removal=dist(a,p)
            if i+1<len(route):
                b=route[i+1];removal+=dist(p,b)-dist(a,b)
            rest=route[:i]+route[i+1:]
            best_delta,best_j=0,i
            for j in range(len(rest)+1):
                a=start if j==0 else rest[j-1]
                insertion=dist(a,p)
                if j<len(rest):
                    b=rest[j];insertion+=dist(p,b)-dist(a,b)
                if insertion-removal<best_delta-1e-6:
                    best_delta,best_j=insertion-removal,j
            if best_j!=i:
                rest.insert(best_j,p);route=rest;changed=True
        if not changed:break
    return route


def portfolio_route(start,points,warm=(),starts=4):
    points=list(dict.fromkeys(points))
    if not points:return []
    candidates=[]
    for first in sorted(points,key=lambda p:dist(start,p))[:starts]:
        route=[first];remaining=[p for p in points if p!=first]
        while remaining:
            p=min(remaining,key=lambda p:dist(route[-1],p))
            remaining.remove(p);route.append(p)
        candidates.append(improve(start,route))
    if warm:
        route=list(dict.fromkeys(p for p in warm if p in points))
        for p in points:
            if p in route:continue
            j=min(range(len(route)+1),key=lambda j:dist(start if j==0 else route[j-1],p)+(
                dist(p,route[j])-dist(start if j==0 else route[j-1],route[j]) if j<len(route)else 0))
            route.insert(j,p)
        candidates.append(improve(start,route))
    return min(candidates,key=lambda r:route_cost(start,r))

"""Interactive menu; no platform call is made by this launcher."""
from pathlib import Path
import os
import subprocess
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent


def main():
    print('B题第三、四问 · 新版演练包（2026-09-12）')
    print('共同7000例本地均值：第三问186.19，第四问426.45秒/源。第四问未达400目标。')
    print('1  第三问本地自检\n2  第四问本地自检\n3  第三问演练\n4  第四问演练\n0  退出')
    answer = input('请选择 0—4：').strip()
    if answer == '0':
        return 0
    if answer not in {'1', '2', '3', '4'}:
        print('选择无效，没有开始测试。')
        return 2
    problem = 3 if answer in {'1', '3'} else 4
    command = [sys.executable, '-B', '-X', 'utf8', str(ROOT / 'practice.py'), '--problem', str(problem)]
    if answer in {'3', '4'}:
        print(f'请先在模拟器开启问题{problem}演练，等待接口就绪。不要选择正式测试。')
        team = input('输入当前登录的真实队号（不是密码，保留前导零）：').strip()
        port = input('端口（回车默认2026，与模拟器一致）：').strip() or '2026'
        if not port.isascii() or not port.isdigit() or not 1 <= int(port) <= 65535:
            print('端口无效，已取消。')
            return 2
        command += ['--backend', 'rehearsal', '--robot-id', team, '--port', port]
    env = os.environ.copy()
    cache = (ROOT / 'cache').resolve()
    if not cache.is_relative_to(ROOT):
        raise ValueError('缓存目录超出演练包，已停止。')
    cache.mkdir(exist_ok=True)
    env.update(PYTHONDONTWRITEBYTECODE='1', TEMP=str(cache), TMP=str(cache))
    return subprocess.run(command, cwd=ROOT, env=env, shell=False).returncode


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (KeyboardInterrupt, EOFError):
        print('已取消。')
        raise SystemExit(2)

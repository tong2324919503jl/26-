"""Small convex geometry operations; metre units, conservative bearing bounds."""
from __future__ import annotations

from itertools import combinations
from math import ceil, cos, hypot, pi, radians, sin

Point = tuple[float, float]
ERROR_DEG = 1.005001  # Physical +/-1 degree plus two-decimal readout rounding.
EPS = 1e-7


def dist(a: Point, b: Point) -> float:
    return hypot(a[0] - b[0], a[1] - b[1])


def cross(a: Point, b: Point, c: Point) -> float:
    return (b[0]-a[0])*(c[1]-a[1]) - (b[1]-a[1])*(c[0]-a[0])


def hull(points):
    points = sorted(set(points))
    if len(points) < 3:
        return points
    lo, hi = [], []
    for seq, out in ((points, lo), (reversed(points), hi)):
        for p in seq:
            while len(out) > 1 and cross(out[-2], out[-1], p) <= 0:
                out.pop()
            out.append(p)
    return lo[:-1] + hi[:-1]


def inside_convex(p, poly, tolerance=EPS):
    if not poly:
        return False
    if len(poly) == 1:
        return dist(p, poly[0]) <= tolerance
    if len(poly) == 2:
        return distance_segment(p, *poly) <= tolerance
    return all(cross(a, b, p) >= -tolerance * max(1, dist(a, b))
               for a, b in zip(poly, poly[1:] + poly[:1]))


def distance_segment(p, a, b):
    vx, vy = b[0]-a[0], b[1]-a[1]
    t = max(0, min(1, ((p[0]-a[0])*vx+(p[1]-a[1])*vy) / (vx*vx+vy*vy or 1)))
    return dist(p, (a[0]+t*vx, a[1]+t*vy))


def clip(poly, nx, ny, offset):
    # Outward relaxation avoids dropping feasible boundary points by rounding.
    offset += EPS * max(1.0, hypot(nx, ny))
    out = []
    if not poly:
        return out
    a = poly[-1]
    fa = nx*a[0]+ny*a[1]-offset
    for b in poly:
        fb = nx*b[0]+ny*b[1]-offset
        if (fa <= 0) != (fb <= 0):
            t = fa / (fa-fb)
            out.append((a[0]+t*(b[0]-a[0]), a[1]+t*(b[1]-a[1])))
        if fb <= 0:
            out.append(b)
        a, fa = b, fb
    return out


def disk_outer(center=(0.0, 0.0), radius=1800.0, sides=128):
    r = radius/cos(pi/sides)
    return [(center[0]+r*cos((2*k+1)*pi/sides),
             center[1]+r*sin((2*k+1)*pi/sides)) for k in range(sides)]


def clip_disk(poly, center, radius=1500.0, sides=64):
    for k in range(sides):
        nx, ny = cos(2*pi*k/sides), sin(2*pi*k/sides)
        poly = clip(poly, nx, ny, nx*center[0]+ny*center[1]+radius)
        if not poly:
            break
    return poly


def clip_bearing(poly, station, angle_deg, error_deg=ERROR_DEG):
    lo, hi = radians(angle_deg-error_deg), radians(angle_deg+error_deg)
    for nx, ny in ((sin(lo), -cos(lo)), (-sin(hi), cos(hi))):
        poly = clip(poly, nx, ny, nx*station[0]+ny*station[1])
    return poly


def exclude_disk(poly, center, radius):
    """Hull of P minus an inscribed disk polygon; conservatively retains G."""
    if not poly or all(dist(p,center) >= radius for p in poly) and (
        not inside_convex(center,poly) and
        min(distance_segment(center,a,b)for a,b in zip(poly,poly[1:]+poly[:1])) >= radius):
        return poly
    inside=list(poly)
    outside=[]
    bound=(radius-0.001)*cos(pi/32)
    for k in range(32):
        nx,ny=cos(k*pi/16),sin(k*pi/16)
        offset=nx*center[0]+ny*center[1]+bound
        outside.extend(clip(inside,-nx,-ny,-offset))
        inside=clip(inside,nx,ny,offset)
        if not inside:
            break
    return hull(outside)


def diameter_pair(poly):
    if not poly:
        raise ValueError("Empty feasible polygon")
    return max(((dist(a, b), a, b) for a in poly for b in poly), key=lambda x: x[0])


def covering_circle(poly):
    """Minimum support circle for a small hull; final radius rechecks every point."""
    pts = hull(poly)
    if not pts:
        raise ValueError("Inconsistent bearing observations: empty feasible region")
    _, a, b = diameter_pair(pts)
    best_c = ((a[0]+b[0])/2, (a[1]+b[1])/2)
    best_r = max(dist(best_c, p) for p in pts)
    # An enclosing circle from the diameter midpoint is sufficient for safety.
    # Triple supports only improve its radius, and never drive feasibility.
    for a, b, c in combinations(pts, 3):
        ux, uy, vx, vy = b[0]-a[0], b[1]-a[1], c[0]-a[0], c[1]-a[1]
        det = 2*(ux*vy-uy*vx)
        if abs(det) < 1e-12*max(1.0, hypot(ux, uy)*hypot(vx, vy)):
            continue
        u2, v2 = ux*ux+uy*uy, vx*vx+vy*vy
        center = (a[0]+(u2*vy-v2*uy)/det, a[1]+(ux*v2-vx*u2)/det)
        radius = max(dist(center, p) for p in pts)
        if radius < best_r:
            best_c, best_r = center, radius
    return best_c, best_r + EPS


def optical_cover(poly, spacing=26.0):
    """Cover an oriented bounding rectangle with disks of radius <20 m."""
    _, a, b = diameter_pair(poly)
    length = dist(a, b)
    ux, uy = ((b[0]-a[0])/length, (b[1]-a[1])/length) if length else (1.0, 0.0)
    coordinates = [((p[0]-a[0])*ux+(p[1]-a[1])*uy,
                    -(p[0]-a[0])*uy+(p[1]-a[1])*ux) for p in poly]
    lowx, highx = min(p[0] for p in coordinates), max(p[0] for p in coordinates)
    lowy, highy = min(p[1] for p in coordinates), max(p[1] for p in coordinates)
    nx, ny = max(1, ceil((highx-lowx)/spacing)), max(1, ceil((highy-lowy)/spacing))
    points = []
    for i in range(nx):
        x = lowx+(i+0.5)*(highx-lowx)/nx
        for j in (range(ny) if i % 2 == 0 else range(ny-1, -1, -1)):
            y = lowy+(j+0.5)*(highy-lowy)/ny
            points.append((a[0]+x*ux-y*uy, a[1]+x*uy+y*ux))
    return points

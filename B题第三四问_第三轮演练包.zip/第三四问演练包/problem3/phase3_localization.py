"""Experimental localization policies using only public observations.

This module is independent of the frozen production policy. All geometry used
for early clear attempts is heuristic; only accepted successful clears count.
The inherited finite enclosure sweep remains the safety fallback.
"""
from __future__ import annotations

import argparse
import json
import math
import statistics
import time
from pathlib import Path

from .policy import Policy
from .geometry import dist, inside_convex, clip, clip_bearing, covering_circle, ERROR_DEG, diameter_pair, hull
from .protocol import Client, output_path
from .simulation import LocalWorld
from .cases import make_case


def project_to_polygon(point, polygon):
    if inside_convex(point, polygon):
        return point
    candidates=[]
    for a,b in zip(polygon,polygon[1:]+polygon[:1]):
        dx,dy=b[0]-a[0],b[1]-a[1]
        fraction=max(0.,min(1.,((point[0]-a[0])*dx+(point[1]-a[1])*dy)/(dx*dx+dy*dy or 1.)))
        candidates.append((a[0]+fraction*dx,a[1]+fraction*dy))
    return min(candidates,key=lambda q:dist(q,point))


def fit_position(track):
    """Iterated weighted center-line fit projected into the safe feasible hull."""
    point, _ = track.circle()
    if len(track.observations)<2 or track.near is not None:
        return point
    for _ in range(6):
        xx=xy=yy=bx=by=0.
        for station,angle in track.observations:
            nx,ny=-math.sin(math.radians(angle)),math.cos(math.radians(angle))
            scale=1./max(100.,dist(station,point)**2)
            rhs=nx*station[0]+ny*station[1]
            xx+=scale*nx*nx;xy+=scale*nx*ny;yy+=scale*ny*ny
            bx+=scale*rhs*nx;by+=scale*rhs*ny
        determinant=xx*yy-xy*xy
        if determinant<=1e-15*(xx+yy)**2:
            break
        candidate=((bx*yy-by*xy)/determinant,(by*xx-bx*xy)/determinant)
        candidate=project_to_polygon(candidate,track.polygon)
        if dist(point,candidate)<1e-5:
            break
        point=candidate
    return point


def enclosure_samples(track):
    """Deterministic quadrature points, not guessed simulator source samples."""
    _,a,b=diameter_pair(track.polygon)
    return [(a[0]+fraction*(b[0]-a[0]),a[1]+fraction*(b[1]-a[1]))
            for fraction in (.1,.3,.5,.7,.9)]


def observation_cost(track, point, current, problem=3):
    """One-step travel plus continuation estimate using bounded observations.

    The quadrature only ranks actions. It never changes the feasible enclosure,
    claims coverage, or serves as a stopping certificate.
    """
    first,_=track.observations[0]
    samples=enclosure_samples(track)
    costs=[]
    for g in samples:
        dq,dp=dist(point,g),dist(first,g)
        if dq<5:
            costs.append(25.)
            continue
        visibility=1.
        if dq>max(1000.,dp):
            visibility=max(0.,min(1.,(1500.-dq)/max(1.,1500.-max(1000.,dp))))
        if problem==4:
            vx,vy=first[0]-g[0],first[1]-g[1]
            wx,wy=point[0]-g[0],point[1]-g[1]
            cs=max(-1.,min(1.,(vx*wx+vy*wy)/max(1e-9,dp*dq)))
            visibility*=1.-math.acos(cs)/math.pi
        angle=math.degrees(math.atan2(g[1]-point[1],g[0]-point[0]))
        continuation=0.
        for noise in (-.9,0.,.9):
            post=clip_bearing(track.polygon,point,angle+noise)
            if not post:
                continuation+=2000.
                continue
            diameter,a,b=diameter_pair(post)
            center=((a[0]+b[0])/2,(a[1]+b[1])/2)
            error=dist(center,g)
            continuation+=dist(point,center)+2.*error+min(120.,.2*diameter)+(35. if error>20 else 0.)
        continuation/=3.
        costs.append(visibility*continuation+(1.-visibility)*(dq+2*min(dp,450.)+60.))
    return dist(current,point)+sum(costs)/len(costs)


def exclude_visibility_cone(polygon, positive_a, positive_b, negative):
    """Conservatively remove G for which negative lies in conv(A,B,G).

    The radio visibility region is convex and contains the emitter itself.
    Thus a negative sample cannot lie in the hull of G and positive samples.
    Outside the forbidden two-ray cone is a union of two halfplanes; its convex
    hull remains an outer bound and is compatible with the existing Track.
    """
    ax,ay=negative[0]-positive_a[0],negative[1]-positive_a[1]
    bx,by=negative[0]-positive_b[0],negative[1]-positive_b[1]
    cross=ax*by-ay*bx
    if abs(cross)<=1e-9*max(1.,math.hypot(ax,ay)*math.hypot(bx,by)):
        return polygon
    if cross<0:
        ax,ay,bx,by=bx,by,ax,ay
    one=clip(polygon,-ay,ax,-ay*negative[0]+ax*negative[1])
    two=clip(polygon,by,-bx,by*negative[0]-bx*negative[1])
    return hull(one+two)


class LocalizationPolicy(Policy):
    def __init__(self, *args, variant="baseline", localization_variant=None, **kwargs):
        super().__init__(*args, **kwargs)
        variant = localization_variant or variant
        self.variant = variant
        if "negative" in variant and self.problem==3:
            for track in self.tracks.values():
                track.omni_negatives=True
        self.phase = "other"
        self.costs = {p: {"time": 0., "distance": 0., "measure": 0, "clear": 0}
                      for p in ("scan", "bystanders", "localize", "other")}

    def measure(self, position, track):
        before, origin = self.api.virtual_time, self.api.position
        result = super().measure(position, track)
        if "visibility" in self.variant and track.polygon and len(track.observations)>=2:
            positives=[p for p,_ in track.observations]
            for negative in track.negative_positions:
                for i,a in enumerate(positives):
                    for b in positives[i+1:]:
                        tightened=exclude_visibility_cone(track.polygon,a,b,negative)
                        if not tightened:
                            raise RuntimeError("Convex radio-visibility constraint contradicts enclosure")
                        track.polygon=tightened
            track._circle=None
        self.costs[self.phase]["time"] += self.api.virtual_time-before
        self.costs[self.phase]["distance"] += dist(origin, position)
        self.costs[self.phase]["measure"] += 1
        return result

    def clear(self, position, track):
        if "fit" in self.variant and track.polygon and track.near is None and dist(position,track.circle()[0])<1e-6:
            candidate=fit_position(track)
            if all(dist(candidate,p)>3 for p in track.failed_clears):
                position=candidate
        if self.variant in ("edge", "fit_edge", "lookahead_edge") and not track.failed_clears:
            radius = max(dist(position, p) for p in track.polygon) if track.polygon else 5.
            slack = max(0., 19.999-radius)
            distance = dist(position, self.api.position)
            if distance and slack:
                fraction = min(slack/distance, 1.)
                position = tuple(a+(b-a)*fraction for a,b in zip(position, self.api.position))
        before, origin = self.api.virtual_time, self.api.position
        result = super().clear(position, track)
        self.costs[self.phase]["time"] += self.api.virtual_time-before
        self.costs[self.phase]["distance"] += dist(origin, position)
        self.costs[self.phase]["clear"] += 1
        return result

    def scan(self, position):
        previous, self.phase = self.phase, "scan"
        try:
            return super().scan(position)
        finally:
            self.phase = previous

    def bystanders(self):
        previous, self.phase = self.phase, "bystanders"
        try:
            return super().bystanders()
        finally:
            self.phase = previous

    def probe(self, track, attempt, losses):
        if self.variant not in ("lookahead","lookahead_edge","lookahead_negative") or losses:
            return super().probe(track,attempt,losses)
        center,radius=track.circle()
        first,theta=track.observations[0]
        ux,uy=math.cos(math.radians(theta)),math.sin(math.radians(theta))
        length=(center[0]-first[0])*ux+(center[1]-first[1])*uy
        candidates=[super().probe(track,attempt,losses)]
        if len(track.observations)==1:
            for fraction in (.15,.4,.65,.9):
                a=max(10.,fraction*length)
                for b in (25.,65.,130.):
                    for sign in (-1.,1.):
                        candidates.append((first[0]+a*ux-sign*b*uy,first[1]+a*uy+sign*b*ux))
        else:
            for theta in range(0,360,45):
                for r in (20.,60.):
                    candidates.append((center[0]+r*math.cos(math.radians(theta)),center[1]+r*math.sin(math.radians(theta))))
        candidates=[q for q in candidates if all(dist(q,p)>3 for p,_ in track.observations)]
        return min(candidates,key=lambda q:observation_cost(track,q,self.api.position,self.problem))

    def paired_probe(self, track):
        if self.variant not in ("nearest_pair", "rebase_pair", "lookahead", "lookahead_edge", "lookahead_pair"):
            return super().paired_probe(track)
        center, radius = track.circle()
        candidates=[]
        observations=track.observations if self.variant=="rebase_pair" else track.observations[:1]
        delta=math.radians(ERROR_DEG)
        for first,theta in observations:
            ux,uy=math.cos(math.radians(theta)),math.sin(math.radians(theta))
            raw_a=(center[0]-first[0])*ux+(center[1]-first[1])*uy
            a=raw_a
            if len(track.observations)==1:
                a=min(self.parameters["advance"], .8*a)
            a=max(1.,a)
            b=max(15.,min(self.parameters["offset"],radius*.13),a*math.tan(delta)+1.)
            combinations=[(a,b)]
            if self.variant=="lookahead_pair":
                distances=[max(1.,raw_a*f)for f in (.15,.4,.65,.9)] if len(track.observations)==1 else [a]
                combinations.extend((a,max(b,a*math.tan(delta)+1.))for a in distances for b in (25.,65.,130.))
            for a,b in combinations:
                plus=(first[0]+a*ux-b*uy,first[1]+a*uy+b*ux)
                minus=(first[0]+a*ux+b*uy,first[1]+a*uy-b*ux)
                three_safe=math.hypot(a,b)<=999.999999 and math.hypot(a-1000*math.cos(delta),b+1000*math.sin(delta))<=999.999999
                local_safe=all(max(dist(q,p)for p in track.polygon)<=999.999999 for q in (plus,minus))
                if not (three_safe or local_safe):
                    continue
                if self.variant=="lookahead_pair":
                    probes=sorted((plus,minus),key=lambda p:observation_cost(track,p,self.api.position,4))
                    score=observation_cost(track,probes[0],self.api.position,4)
                else:
                    probes=sorted((plus,minus),key=lambda p:dist(self.api.position,p))
                    score=dist(self.api.position,probes[0])
                candidates.append((score,probes,first,(ux,uy),a))
        if not candidates:
            return None
        _,probes,first,(ux,uy),a=min(candidates,key=lambda row:row[0])
        result=self.measure(probes[0],track)["measure_result"]
        if result!="no_signal":
            return result
        result=self.measure(probes[1],track)["measure_result"]
        if result!="no_signal":
            return result
        tightened=clip(track.polygon,ux,uy,ux*first[0]+uy*first[1]+a)
        if not tightened:
            raise RuntimeError("Rebased paired measurements contradict enclosure")
        track.polygon,track._circle=tightened,None
        track.paired_radial_cuts+=1
        return "radial_cut"

    def localize(self, track):
        previous, self.phase = self.phase, "localize"
        try:
            return super().localize(track)
        finally:
            self.phase = previous

    def run(self):
        result = super().run()
        result["localization_variant"] = self.variant
        result["phase_costs"] = self.costs
        return result


def factory(api, problem, parameters=None, localization_variant="lookahead_negative", **options):
    if parameters is None:
        root=Path(__file__).resolve().parent.parent
        parameters=json.loads((root/f"problem{problem}/config.json").read_text(encoding="utf-8"))["parameters"]
    return LocalizationPolicy(api,problem,"portfolio",parameters=parameters,
                              localization_variant=localization_variant,**options)


def evaluate(case, variant):
    root = Path(__file__).resolve().parent.parent
    config = json.loads((root/f"problem{case['problem']}/config.json").read_text(encoding="utf-8"))
    world = LocalWorld(case)
    api = Client(world.exchange, real_guard=False)
    policy = LocalizationPolicy(api, case["problem"], config["branch"],
                                parameters=config["parameters"], variant=variant)
    started = time.perf_counter()
    try:
        result = policy.run()
    except Exception as exc:
        result = {"complete_certificate": False, "error": repr(exc), "phase_costs": policy.costs}
    metrics = world.final_metrics()
    return {"case": case["name"], "family": case["family"], "variant": variant,
            **metrics, "policy": result,
            "complete": result["complete_certificate"] and metrics["source_count"] == metrics["cleared_count"],
            "average_time_s": metrics["virtual_time_s"]/max(metrics["cleared_count"], 1),
            "runtime_s": time.perf_counter()-started}


def summarize(rows):
    return {variant: {
        "cases": len(group), "complete": sum(r["complete"] for r in group),
        "mean_seconds_per_source": statistics.mean(r["average_time_s"] for r in group),
        "mean_distance_m": statistics.mean(r["distance_m"] for r in group),
        "mean_measure": statistics.mean(r["policy"].get("actions", {}).get("measure",0) for r in group),
        "mean_clear": statistics.mean(r["policy"].get("actions", {}).get("clear",0) for r in group),
        "max_runtime_s": max(r["runtime_s"] for r in group),
        "mean_phases": {phase: {key: statistics.mean(r["policy"]["phase_costs"][phase][key] for r in group)
                                 for key in ("time", "distance", "measure", "clear")}
                        for phase in ("scan", "bystanders", "localize", "other")},
        "failed_cases": [r["case"] for r in group if not r["complete"]]}
        for variant in sorted({r["variant"] for r in rows})
        if (group := [r for r in rows if r["variant"] == variant])}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--problem", required=True, type=int, choices=(3,4))
    parser.add_argument("--count", type=int, default=224)
    parser.add_argument("--split", default="train")
    parser.add_argument("--variants", nargs="+", default=["baseline","edge"])
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    output = output_path(args.output)
    if output.exists():
        parser.error("Refusing to overwrite previous experiment")
    rows=[]
    for i in range(args.count):
        case = make_case(args.problem,args.split,i)
        for variant in args.variants:
            rows.append(evaluate(case,variant))
        if (i+1)%16==0:
            print(json.dumps({"done":i+1,"means":{v: round(statistics.mean(r['average_time_s'] for r in rows if r['variant']==v),3) for v in args.variants}}),flush=True)
    result={"data_origin":"local_simulation_not_official","problem":args.problem,
            "split":args.split,"summary":summarize(rows),"rows":rows}
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(result['summary'],ensure_ascii=False,indent=2))


if __name__ == "__main__":
    main()

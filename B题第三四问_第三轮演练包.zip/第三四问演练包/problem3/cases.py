"""Diverse, reproducible local cases; generated truth is never passed to policy."""
from __future__ import annotations

import math
import random

FAMILIES = ("uniform", "boundary", "clusters", "line", "outward", "tangent", "lattice", "mixed_scale")
NOISES = ("hash", "smooth", "fixed_extreme", "striped")
SPLIT_SEEDS = {"pilot": 730001, "train": 1300001, "validation": 4300001,
               "holdout": 9300001, "stress": 17300001,
               "phase2_validation": 271000003, "phase2_holdout": 397000003,
               "phase2_stress": 613000003}


def make_case(problem, split, index):
    seed = SPLIT_SEEDS[split]+100003*problem+7919*index
    rng = random.Random(seed)
    family = FAMILIES[index % len(FAMILIES)]
    n = 10 + (index//len(FAMILIES) + index) % 7
    channels = rng.sample(range(1, 21), n)
    rot = rng.uniform(0, 2*math.pi)
    centers = [(rng.uniform(-900, 900), rng.uniform(-900, 900)) for _ in range(3)]
    directional_count = 0 if problem == 3 else 1 + ((index*5+index//8) % (n-1))
    directed = set(rng.sample(range(n), directional_count))
    sources = []
    for k, channel in enumerate(channels):
        a = rng.uniform(0, 2*math.pi)
        r = 1800*math.sqrt(rng.random())
        if family in ("boundary", "outward", "tangent"):
            r = rng.uniform(1680, 1800)
            a = rot+2*math.pi*k/n+rng.uniform(-0.07, 0.07)
        elif family == "clusters":
            cx, cy = centers[k % len(centers)]
            x, y = rng.gauss(cx, 65), rng.gauss(cy, 65)
            r, a = min(1799, math.hypot(x, y)), math.atan2(y, x)
        elif family == "line":
            x, y = rng.uniform(-1770, 1770), rng.uniform(-12, 12)
            r, a = math.hypot(x, y), math.atan2(y, x)+rot
        elif family == "lattice":
            # Deliberately offset and rotate relative to the policy's coverage lattice.
            x, y = rng.choice((-1350, -675, 0, 675, 1350)), rng.choice((-1200, -600, 0, 600, 1200))
            r, a = min(1799.999, math.hypot(x, y)), math.atan2(y, x)+rot
        elif family == "mixed_scale":
            r = rng.choice((rng.uniform(0.1, 25), rng.uniform(980, 1020), rng.uniform(1700, 1800)))
        position = (r*math.cos(a), r*math.sin(a))
        orientation = rng.uniform(0, 360)
        if family == "outward":
            orientation = math.degrees(a)+rng.uniform(-12, 12)
        elif family == "tangent":
            orientation = math.degrees(a)+rng.choice((-90, 90))+rng.uniform(-0.2, 0.2)
        radius = (1000.0 if family in ("boundary", "outward", "lattice") else
                  rng.uniform(1000, 1080) if index % 3 else rng.uniform(1000, 1500))
        if split.endswith("stress"):
            # Distribution shift: exact rim, dense small clouds, angular cutoffs,
            # minimum reception radius, and almost all sources directional.
            r = (1800.0 if index % 4 == 0 else rng.uniform(850, 940) if index % 4 == 1
                 else rng.uniform(0.001, 15) if index % 4 == 2 else rng.uniform(1500,1800))
            position = (r*math.cos(a), r*math.sin(a))
            radius = 1000.0
            if problem == 4:
                directed = set(range(n-1))
                orientation = math.degrees(a)+(90 if k % 2 else -90)+rng.choice((-1e-6,1e-6))
        sources.append({"channel": channel, "xy": list(position), "radius": radius,
                        "directional": k in directed, "orientation_deg": orientation % 360,
                        "noise_phase": rng.uniform(0, 2*math.pi)})
    return {"name": f"p{problem}-{split}-{index:04d}-{family}", "problem": problem,
            "data_origin": "locally_generated_not_official", "split": split, "family": family,
            "noise_mode": (("fixed_extreme" if index % 2 else "striped") if split.endswith("stress")
                           else NOISES[(index//8+index) % len(NOISES)]), "noise_seed": seed,
            "sources": sources}

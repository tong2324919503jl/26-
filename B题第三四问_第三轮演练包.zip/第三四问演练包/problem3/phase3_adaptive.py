"""Adapt the search itinerary using the actual initial negative observations."""
from math import cos,sin,pi
from .phase3_localization import LocalizationPolicy
from .phase3_route import RoutePolicy


class AdaptivePolicy(RoutePolicy,LocalizationPolicy):
    def __init__(self,api,problem,parameters=None,radius=1450,localization='negative'):
        if problem!=3 or not 1124<=radius<=1730:
            raise ValueError('Certified omni adaptive radius only')
        super().__init__(api,problem,variant='milestone',parameters=parameters)
        self.variant=localization
        self.outer_radius=radius
        self.initial_annulus=False
        if 'negative' in localization:
            for t in self.tracks.values():
                t.omni_negatives=True

    def scan(self,position):
        super().scan(position)
        if self.scan_stops==1 and tuple(position)==(0.,0.) and not self.known_pending():
            # Every channel was absent at the origin. Under problem 3 all
            # remaining sources are outside the 1000m disk; no prior over
            # official cases or source count is inferred from this feedback.
            self.initial_annulus=True
            r=self.outer_radius
            self.coverage.anchors=((0.,0.),)+tuple((r*cos(k*pi/3),r*sin(k*pi/3))for k in range(6))

    def next_step(self,track):
        previous,self.phase=self.phase,'localize'
        try:
            return super().next_step(track)
        finally:
            self.phase=previous


def factory(api,problem,parameters=None,**options):
    return AdaptivePolicy(api,problem,parameters,**options)

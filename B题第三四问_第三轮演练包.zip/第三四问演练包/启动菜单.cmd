@echo off
setlocal
cd /d "%~dp0"
set PYTHONDONTWRITEBYTECODE=1
python -B -X utf8 start.py
if errorlevel 1 echo Stopped. See the message above. Python 3.10+ is required.
pause

from pathlib import Path
import sys
sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from practice import main

if __name__ == '__main__':
    try:
        raise SystemExit(main(4))
    except (ValueError, RuntimeError, OSError, KeyboardInterrupt, EOFError) as exc:
        print(f'启动已停止：{exc}', file=sys.stderr)
        raise SystemExit(2)

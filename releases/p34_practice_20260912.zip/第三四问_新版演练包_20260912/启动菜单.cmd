@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
set "PYTHONDONTWRITEBYTECODE=1"
set "TEMP=%~dp0cache"
set "TMP=%~dp0cache"
if not exist "%TEMP%" mkdir "%TEMP%"
set "RUNPY=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
if exist "%RUNPY%" (
  "%RUNPY%" -B -X utf8 start.py
) else (
  python -B -X utf8 start.py
)
if errorlevel 1 echo Stopped. Please read the error above.
pause

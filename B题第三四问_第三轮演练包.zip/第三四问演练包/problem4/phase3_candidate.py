"""Problem 4 research candidate selected on the unchanged training cases."""
from functools import lru_cache
import json

from problem3.coverage_certificate import verify_certificate
from problem3.phase3_optical import factory as optical_factory
from problem3.protocol import output_path


@lru_cache(maxsize=1)
def stations():
    document=json.loads(output_path('problem4/results/phase3_cover_opt_certificate.json').read_text(encoding='utf-8'))
    if not verify_certificate(document):
        raise ValueError('Continuous directional coverage certificate failed')
    points=tuple(tuple(p) for p in document['stations'])
    if points[0]!=(0.,0.):
        raise ValueError('Origin must retain index zero')
    return points


def factory(api,problem=4,parameters=None):
    if problem!=4:
        raise ValueError('This research candidate is for problem 4')
    policy=optical_factory(api,4,parameters=parameters,max_length=200,max_width=32,optical_mode='unionmass')
    policy.coverage.anchors=stations()
    return policy

"""Independent local physics emulator. This module never contacts the official platform."""
from __future__ import annotations

import hashlib
import json
import math


class LocalWorld:
    def __init__(self, case):
        self._case = case
        self._sources = {s["channel"]: dict(s) for s in case["sources"]}
        self._cleared = set()
        self._position = (0.0, 0.0)
        self._channel = 1
        self._virtual_us = 0
        self._entered = self._exited = False
        self._memo = {}
        self._movement = self._switches = 0.0
        self._near_count = 0
        self._validate()

    def _validate(self):
        sources = list(self._sources.values())
        if len(sources) != len(self._case["sources"]) or not 10 <= len(sources) <= 16:
            raise ValueError("Each of 10..16 sources must have a distinct channel")
        for s in sources:
            if (not 1 <= s["channel"] <= 20 or math.hypot(*s["xy"]) > 1800+1e-7
                    or not 1000 <= s["radius"] <= 1500):
                raise ValueError("Local source violates physical rules")
        if self._case["problem"] == 3 and any(s["directional"] for s in sources):
            raise ValueError("Problem 3 only has omnidirectional sources")
        if self._case["problem"] == 4 and not 0 < sum(s["directional"] for s in sources) < len(sources):
            raise ValueError("Problem 4 cases must contain both source types")

    def _error(self, source, p):
        # Fixed position => fixed error, across every repeated observation.
        mode = self._case["noise_mode"]
        phase = source["noise_phase"]
        if mode == "fixed_extreme":
            return 1.0 if math.sin(phase) >= 0 else -1.0
        if mode == "smooth":
            return math.sin(phase+p[0]/110.0+p[1]/173.0)
        if mode == "striped":
            return 0.9999 if math.sin(p[0]/47+p[1]/71+phase) >= 0 else -0.9999
        raw = f'{self._case["noise_seed"]}|{source["channel"]}|{p[0]:.9f}|{p[1]:.9f}'.encode()
        integer = int.from_bytes(hashlib.blake2b(raw, digest_size=8).digest(), "big")
        return 2*integer/(2**64-1)-1

    def exchange(self, path, payload):
        key = payload["request_id"]
        fingerprint = json.dumps([path, payload], sort_keys=True, allow_nan=False)
        if key in self._memo:
            old_fingerprint, old_response = self._memo[key]
            if fingerprint != old_fingerprint:
                raise RuntimeError("Idempotency conflict")
            return dict(old_response)
        response = {"accepted": False, "real_timestamp_ms": 0, "virtual_time_s": 0}
        if path == "/enter" and not self._entered:
            self._entered = True
            response.update(accepted=True, max_virtual_duration_s=360000,
                            max_real_duration_s=1200, remaining_real_duration_s=1200)
        elif not self._entered or self._exited:
            return response
        elif path == "/exit":
            self._exited = True
            response.update(accepted=True, virtual_time_s=self._virtual_us/1e6, exit_reason="user_exit")
        elif path in ("/measure", "/clear"):
            p = float(payload["position"]["x"]), float(payload["position"]["y"])
            channel = payload["channel"]
            movement = math.dist(self._position, p)
            seconds = movement/5
            self._movement += movement
            self._position = p
            source = self._sources.get(channel) if channel not in self._cleared else None
            distance = math.dist(p, source["xy"]) if source else math.inf
            if path == "/clear":
                success = distance <= 20
                if success:
                    self._cleared.add(channel)
                seconds += 5 if success else 3
                response["clear_result"] = "success" if success else "no_target_in_range"
            else:
                switch = channel != self._channel
                self._switches += switch
                seconds += 5+switch
                self._channel = channel
                visible = source is not None and distance <= source["radius"]
                if visible and source["directional"]:
                    orientation = math.radians(source["orientation_deg"])
                    visible = ((p[0]-source["xy"][0])*math.cos(orientation)
                               +(p[1]-source["xy"][1])*math.sin(orientation)) >= -1e-10
                if not visible:
                    response["measure_result"] = "no_signal"
                elif distance <= 5:
                    response["measure_result"] = "near"
                    self._near_count += 1
                else:
                    angle = math.degrees(math.atan2(source["xy"][1]-p[1], source["xy"][0]-p[0]))
                    response.update(measure_result="direction",
                                    svd_deg=round((angle+self._error(source, p)) % 360, 2) % 360)
            self._virtual_us += round(seconds*1e6)
            response.update(accepted=True, virtual_time_s=self._virtual_us/1e6)
        else:
            return response
        self._memo[key] = fingerprint, dict(response)
        return response

    def final_metrics(self):
        # Called by evaluation only, after the policy has finished.
        return {"source_count": len(self._sources), "cleared_count": len(self._cleared),
                "remaining_channels": sorted(set(self._sources)-self._cleared),
                "virtual_time_s": self._virtual_us/1e6, "distance_m": self._movement,
                "switches": self._switches, "near_count": self._near_count}

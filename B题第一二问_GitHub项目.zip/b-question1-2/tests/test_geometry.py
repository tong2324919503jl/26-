import json
import math
import random
import unittest
from pathlib import Path

from b12.__main__ import analyze_question1
from b12.geometry import (
    Bearing, HalfPlane, bearing_halfplanes, clip_polygon, convex_hull,
    diameter_bruteforce, diameter_calipers, distance, intersect_halfplanes,
    localize, minimum_enclosing_circle, outer_disk_polygon,
)

ROOT = Path(__file__).resolve().parents[1]


class GeometryTests(unittest.TestCase):
    def test_triangle_is_attainable_and_diameter_disk_fails(self):
        data = json.loads((ROOT / "examples/q1_triangle.json").read_text(encoding="utf-8"))
        readings = [Bearing(**r) for r in data["readings"]]
        result = analyze_question1(readings)
        self.assertEqual(result["status"], "polygon")
        self.assertEqual(len(result["vertices_m"]), 3)
        self.assertAlmostEqual(result["diameter_m"], 40.0, places=8)
        self.assertAlmostEqual(result["minimum_enclosing_circle"]["radius"], 40 / math.sqrt(3), places=8)
        self.assertFalse(result["diameter_circle_covers"])
        self.assertFalse(result["guaranteed_clear_from_enclosing_center"])
        true_source = (20.0, 40 * math.sqrt(3) / 6)
        for reading in readings:
            actual = math.degrees(math.atan2(true_source[1] - reading.y, true_source[0] - reading.x))
            error = (reading.bearing_deg - actual + 180) % 360 - 180
            self.assertLessEqual(abs(error), 1.0)
            self.assertLess(distance(reading.position, true_source), 1200.0)

    def test_unbounded_is_not_clipped_to_an_arbitrary_box(self):
        region = localize([Bearing(0, 0, 0)])
        self.assertEqual(region.status, "unbounded")
        self.assertIsNotNone(region.recession)
        result = analyze_question1([Bearing(0, 0, 0)])
        self.assertIsNone(result["diameter_m"])
        self.assertTrue(result["diameter_infinite"])

    def test_empty_wedges(self):
        self.assertEqual(localize([Bearing(0, 0, 0), Bearing(-10, 0, 180)]).status, "empty")

    def test_point_and_segment(self):
        point = localize([Bearing(0, 0, 0), Bearing(0, 0, 180)])
        self.assertEqual(point.status, "point")
        segment = localize([Bearing(0, 0, 1), Bearing(0, 0, -1), Bearing(10, 0, 180)])
        self.assertEqual(segment.status, "segment")
        self.assertAlmostEqual(diameter_calipers(segment.vertices)[0], 10.0, places=8)

    def test_angle_wrap_and_forward_direction(self):
        for bearing in (-0.5, 359.5, 719.5):
            planes = bearing_halfplanes(Bearing(0, 0, bearing))
            self.assertTrue(all(p.contains((100, 0)) for p in planes))
            self.assertFalse(all(p.contains((-100, 0)) for p in planes))

    def test_parallel_strip_and_infeasible_parallel_planes(self):
        strip = intersect_halfplanes([HalfPlane(1, 0, 1), HalfPlane(-1, 0, 0)])
        self.assertEqual(strip.status, "unbounded")
        empty = intersect_halfplanes([HalfPlane(1, 0, -1), HalfPlane(-1, 0, 0)])
        self.assertEqual(empty.status, "empty")

    def test_rectangle_diameter_circle(self):
        rectangle = intersect_halfplanes([
            HalfPlane(1, 0, 3), HalfPlane(-1, 0, 0), HalfPlane(0, 1, 4), HalfPlane(0, -1, 0),
        ])
        self.assertEqual(rectangle.status, "polygon")
        self.assertAlmostEqual(diameter_calipers(rectangle.vertices)[0], 5.0)
        self.assertAlmostEqual(minimum_enclosing_circle(rectangle.vertices).radius, 2.5)

    def test_translation_and_large_coordinates(self):
        for offset in (0.0, 1_000_000.0):
            region = intersect_halfplanes([
                HalfPlane(1, 0, offset + 3), HalfPlane(-1, 0, -offset),
                HalfPlane(0, 1, offset + 4), HalfPlane(0, -1, -offset),
            ])
            self.assertAlmostEqual(diameter_calipers(region.vertices)[0], 5.0)

    def test_calipers_against_independent_pair_enumeration(self):
        rng = random.Random(20260910)
        for _ in range(200):
            hull = convex_hull([(rng.uniform(-1000, 1000), rng.uniform(-1000, 1000)) for _ in range(35)])
            self.assertAlmostEqual(diameter_calipers(hull)[0], diameter_bruteforce(hull)[0], places=8)
        for sides in (4, 6, 8, 20):
            polygon = [(math.cos(2 * math.pi * k / sides), math.sin(2 * math.pi * k / sides)) for k in range(sides)]
            self.assertAlmostEqual(diameter_calipers(polygon)[0], diameter_bruteforce(polygon)[0], places=12)

    def test_random_compatible_observations_contain_truth(self):
        rng = random.Random(4401)
        for _ in range(100):
            source = rng.uniform(-200, 200), rng.uniform(-200, 200)
            readings = []
            for k in range(4):
                direction = 2 * math.pi * (k / 4 + rng.uniform(-0.04, 0.04))
                radius = rng.uniform(300, 1000)
                sensor = source[0] + radius * math.cos(direction), source[1] + radius * math.sin(direction)
                bearing = math.degrees(math.atan2(source[1] - sensor[1], source[0] - sensor[0])) + rng.uniform(-1, 1)
                readings.append(Bearing(*sensor, bearing))
            region = localize(readings)
            self.assertEqual(region.status, "polygon")
            self.assertTrue(all(h.contains(source) for r in readings for h in bearing_halfplanes(r)))
            # 用独立的凸包边叉积判定真值确实在返回的区域内。
            for p, q in zip(region.vertices, region.vertices[1:] + region.vertices[:1]):
                area = (q[0] - p[0]) * (source[1] - p[1]) - (q[1] - p[1]) * (source[0] - p[0])
                self.assertGreaterEqual(area, -1e-6)

    def test_outer_circle_contains_circle_and_clipping_preserves_boundary(self):
        polygon = outer_disk_polygon((0, 0), 10, 16)
        for angle in range(360):
            p = 10 * math.cos(math.radians(angle)), 10 * math.sin(math.radians(angle))
            for a, b in zip(polygon, polygon[1:] + polygon[:1]):
                self.assertGreaterEqual((b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0]), -1e-9)
        self.assertEqual(sorted(clip_polygon([(0, 0), (10, 0)], HalfPlane(1, 0, 5))), [(0.0, 0.0), (5.0, 0.0)])

    def test_invalid_readings_and_empty_input(self):
        for error in (0, 90, -1, math.nan):
            with self.assertRaises(ValueError):
                Bearing(0, 0, 0, error)
        with self.assertRaises(ValueError):
            localize([])


if __name__ == "__main__":
    unittest.main()

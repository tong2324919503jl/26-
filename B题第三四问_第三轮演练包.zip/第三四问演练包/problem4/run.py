"""Problem 4 practice entry point."""
import sys
sys.dont_write_bytecode = True
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from problem3.run import main

if __name__ == "__main__":
    try:
        raise SystemExit(main(4))
    except (ValueError, OSError, KeyboardInterrupt) as exc:
        print(f"启动已停止：{exc}", file=sys.stderr)
        raise SystemExit(2)

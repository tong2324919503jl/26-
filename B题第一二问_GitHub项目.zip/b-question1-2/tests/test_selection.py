import math
import random
import unittest

from b12.geometry import Bearing, bearing_halfplanes, clip_with_bearing, diameter_bruteforce, distance
from b12.selection import (
    DiameterBoundEvaluator, SearchConfig, bearing_clearance, candidate_allowed,
    first_region_outer, select_second_point, signal_safe, to_local, to_world,
)


class SelectionTests(unittest.TestCase):
    def test_safe_region_handles_unknown_radius_using_first_detection(self):
        self.assertTrue(candidate_allowed(800, 600))
        self.assertTrue(candidate_allowed(800, -600))
        self.assertFalse(signal_safe(0, 750))
        self.assertFalse(candidate_allowed(750, 0))
        rng = random.Random(7123)
        for _ in range(2000):
            a, b = rng.uniform(0, 1000), rng.uniform(-1000, 1000)
            if not signal_safe(a, b):
                continue
            for r in (0, 5, 500, 1000, 1500):
                for phi in (-1, -0.5, 0, 0.5, 1):
                    source = r * math.cos(math.radians(phi)), r * math.sin(math.radians(phi))
                    self.assertLessEqual(distance((a, b), source), max(1000, r) + 1e-8)

    def test_perpendicular_motion_can_lose_signal(self):
        self.assertGreater(distance((0, 750), (1500, 0)), 1500)

    def test_reception_proof_is_not_fixed_1000_radius(self):
        # 在 1500 米处被首次测得，说明该源半径为 1500；安全点可距源超过 1000。
        self.assertTrue(signal_safe(400, 400))
        self.assertGreater(distance((400, 400), (1500, 0)), 1000)
        self.assertLess(distance((400, 400), (1500, 0)), 1500)

    def test_coordinate_transformation(self):
        reading = Bearing(123, -45, 237)
        local = (800, -600)
        recovered = to_local(reading, to_world(reading, *local))
        self.assertAlmostEqual(recovered[0], local[0])
        self.assertAlmostEqual(recovered[1], local[1])

    def test_target_disk_reduces_range_near_boundary(self):
        polygon = first_region_outer(Bearing(1500, 0, 0))
        self.assertLess(max(p[0] for p in polygon), 1800.1)
        self.assertGreaterEqual(min(p[0] for p in polygon), 1500 - 1e-8)

    def test_widened_grid_bound_covers_off_grid_angles(self):
        reading = Bearing(0, 0, 0)
        polygon = first_region_outer(reading)
        point = (800.0, 600.0)
        evaluator = DiameterBoundEvaluator(polygon, 1, 2.0)
        upper = evaluator.evaluate(point).diameter_upper_m
        rng = random.Random(390)
        for _ in range(500):
            angle = rng.uniform(0, 360)
            intersection = clip_with_bearing(polygon, Bearing(*point, angle))
            if intersection:
                self.assertLessEqual(diameter_bruteforce(intersection)[0], upper + 1e-7)

    def test_half_cell_widening_contains_each_actual_wedge(self):
        # 独立的点级判定检验包络证明，包括 0/360 度附近。
        rng = random.Random(771)
        step, error = 2.0, 1.0
        for _ in range(500):
            angle = rng.uniform(0, 360)
            nearest = round(angle / step) * step
            actual_ray = angle + rng.uniform(-error, error)
            p = 100 * math.cos(math.radians(actual_ray)), 100 * math.sin(math.radians(actual_ray))
            widened = Bearing(0, 0, nearest, error + step / 2)
            self.assertTrue(all(h.contains(p) for h in bearing_halfplanes(widened)))

    def test_selection_uses_only_first_reading_and_is_safe(self):
        config = SearchConfig(stages=((250, 15, 5),), final_angle_step_deg=2)
        result = select_second_point(Bearing(0, 0, 0), config)
        a, b = result["selected_local_m"]
        self.assertTrue(candidate_allowed(a, b))
        self.assertGreater(bearing_clearance(a, b), 5)
        self.assertLess(result["worst_diameter_upper_m"], 500)
        self.assertFalse(result["continuous_global_optimum_proven"])
        self.assertTrue(result["finite_candidate_set_minimizer"])
        diagonal = (1000 / math.sqrt(2), 1000 / math.sqrt(2))
        baseline = DiameterBoundEvaluator(first_region_outer(Bearing(0, 0, 0)), 1, 2).evaluate(diagonal)
        self.assertLessEqual(result["worst_diameter_upper_m"], baseline.diameter_upper_m + 1e-7)

    def test_empty_first_region_is_rejected(self):
        with self.assertRaises(ValueError):
            select_second_point(Bearing(4000, 0, 0), SearchConfig(stages=((500, 30, 10),)))


if __name__ == "__main__":
    unittest.main()

"""Online discovery, bounded-error localization, and finite optical fallback."""
from __future__ import annotations

from dataclasses import dataclass, field
from math import cos, hypot, isfinite, radians, sin, tan
import time

from .coverage import Coverage, shortest_open_route
from .geometry import ERROR_DEG, clip, clip_bearing, clip_disk, covering_circle, disk_outer, dist, optical_cover, exclude_disk
from .protocol import BudgetExceeded

BRANCHES = ("baseline", "adaptive", "hybrid", "efficient", "paired", "joint", "agile", "relay", "stereo", "orbit", "weave", "portfolio")


@dataclass
class Track:
    channel: int
    observations: list = field(default_factory=list)
    polygon: list = field(default_factory=list)
    near: tuple | None = None
    failed_clears: list = field(default_factory=list)
    no_signal_count: int = 0
    geometry_resets: int = 0
    paired_radial_cuts: int = 0
    _circle: tuple | None = None
    omni_negatives: bool = False
    negative_positions: list = field(default_factory=list)

    @property
    def known(self):
        return bool(self.observations) or self.near is not None

    def record(self, position, response):
        result = response["measure_result"]
        if result == "near":
            self.near = position
        elif result == "no_signal":
            self.no_signal_count += 1
            self.negative_positions.append(position)
            if self.omni_negatives and self.polygon:
                self.polygon = exclude_disk(self.polygon,position,1000)
                self._circle = None
        else:
            angle = response["svd_deg"]
            if any(dist(position, p) < 1e-6 for p, _ in self.observations):
                return  # Repeated fixed-position observations add no information.
            old = self.polygon or disk_outer()
            updated = clip_disk(clip_bearing(old, position, angle), position)
            self.observations.append((position, angle))
            if not updated:
                # Use the original broad first-observation enclosure for optical fallback.
                first, theta = self.observations[0]
                updated = clip_disk(clip_bearing(disk_outer(), first, theta), first)
                self.geometry_resets += 1
            self.polygon = updated
            if self.omni_negatives:
                for p in self.negative_positions:
                    self.polygon = exclude_disk(self.polygon,p,1000)
            self._circle = None

    def circle(self):
        if self.near is not None:
            return self.near, 5.0
        if self._circle is None:
            self._circle = covering_circle(self.polygon)
        return self._circle


class Policy:
    def __init__(self, api, problem, branch="paired", max_actions=10000, parameters=None):
        if problem not in (3, 4) or branch not in BRANCHES:
            raise ValueError("Unknown problem or algorithm branch")
        self.api, self.problem, self.branch = api, problem, branch
        self.tracks = {c: Track(c) for c in range(1, 21)}
        if branch in ("agile","relay","stereo"):
            for t in self.tracks.values():
                t.omni_negatives = problem == 3
        self.coverage = Coverage(problem, "joint" if branch in ("agile","relay","stereo","orbit","weave","portfolio") else branch)
        self.warm_route=[]
        self.max_actions = max_actions
        self.fallbacks = 0
        self.scan_stops = 0
        self.reason = ""
        self.parameters = {"advance": 450.0, "offset": 90.0, "clear_radius": 55.0, "scan_gain": 0.015,
                           "stereo_step": 200.0, "coverage_radius": 1500.0, "route_starts": 4}
        if parameters and set(parameters) - set(self.parameters):
            raise ValueError("Unknown policy parameters")
        self.parameters.update(parameters or {})
        if not all(isfinite(v) and v > 0 for v in self.parameters.values()) or max_actions < 1:
            raise ValueError("Policy parameters and action budget must be positive")
        if isinstance(self.parameters["route_starts"],bool) or not isinstance(self.parameters["route_starts"],int) or not 1<=self.parameters["route_starts"]<=16:
            raise ValueError("route_starts must be an integer in 1..16")
        if self.branch in ("orbit","weave","portfolio") and problem == 3:
            r=self.parameters["coverage_radius"]
            if not 1124 <= r <= 1730:
                raise ValueError("Uncertified omni coverage radius")
            self.coverage.anchors=((0.,0.),)+tuple((r*cos(k*radians(60)),r*sin(k*radians(60)))for k in range(6))

    def unknown(self):
        return [c for c, t in self.tracks.items() if not t.known and c not in self.api.cleared]

    def known_pending(self):
        return [t for c, t in self.tracks.items() if t.known and c not in self.api.cleared]

    def check_budget(self):
        if self.api.counts["measure"]+self.api.counts["clear"] >= self.max_actions:
            raise BudgetExceeded("动作预算耗尽，不能声称全部完成")

    def measure(self, position, track):
        self.check_budget()
        response = self.api.measure(position, track.channel)
        track.record(tuple(position), response)
        return response

    def clear(self, position, track):
        self.check_budget()
        response = self.api.clear(position, track.channel)
        if response["clear_result"] == "success":
            return True
        track.failed_clears.append(tuple(position))
        return False

    def scan(self, position):
        pending = self.unknown()
        if not pending:
            return
        # Minimize the first switch, while keeping all actions strictly serial.
        pending.sort(key=lambda c: (c != self.api.channel, c))
        for channel in pending:
            self.measure(position, self.tracks[channel])
        self.coverage.add(tuple(position))
        self.scan_stops += 1
        if self.branch == "stereo":
            uncertain=[t for t in self.known_pending() if t.observations and t.circle()[1]>70]
            if uncertain:
                # Shared second station: geometry chosen from public bearings only.
                theta=radians(sum(t.observations[-1][1] for t in uncertain)/len(uncertain)+90)
                if hypot(*position)>100:
                    ux,uy=-position[1]/hypot(*position),position[0]/hypot(*position)
                else:
                    ux,uy=cos(theta),sin(theta)
                step=self.parameters["stereo_step"]
                q=(position[0]+step*ux,position[1]+step*uy)
                for t in uncertain:
                    self.measure(q,t)

    def bystanders(self):
        if self.branch not in ("hybrid", "efficient", "paired", "joint", "agile", "relay", "stereo", "orbit", "weave", "portfolio"):
            return
        p = self.api.position
        for track in self.known_pending():
            if track.near is not None or not track.observations:
                continue
            center, radius = track.circle()
            previous = track.observations[-1][0]
            distance_limit, baseline_limit = (1500+radius,70) if self.branch == "relay" else (950,250)
            if radius > 35 and dist(p, center) < distance_limit and dist(p, previous) > baseline_limit:
                self.measure(p, track)

    def probe(self, track, attempt, losses):
        center, radius = track.circle()
        first, theta = track.observations[0]
        angle = radians(theta)
        ux, uy = cos(angle), sin(angle)
        sign = 1 if track.channel % 2 else -1
        if losses:
            advance = min(250.0, dist(first, center)*0.4)
            offset = 60.0 * (-sign if losses % 2 else sign)
            return first[0]+advance*ux-offset*uy, first[1]+advance*uy+offset*ux
        if len(track.observations) == 1:
            if self.branch == "baseline":
                advance, offset = min(750.0, dist(first, center)), min(350.0, radius*0.45)*sign
            else:
                advance = min(self.parameters["advance"], dist(first, center)*0.8)
                offset = min(self.parameters["offset"], max(15.0, radius*0.12))*sign
            return first[0]+advance*ux-offset*uy, first[1]+advance*uy+offset*ux
        offset = min(50.0, max(12.0, radius*0.18))*sign
        candidate = center[0]-offset*uy, center[1]+offset*ux
        if any(dist(candidate, p) < 2 for p, _ in track.observations):
            offset *= -1.7
            candidate = center[0]-offset*uy, center[1]+offset*ux
        return candidate

    def paired_probe(self, track):
        """Both probes missing implies source is before their common forward coordinate."""
        center, radius = track.circle()
        first, theta = track.observations[0]
        ux, uy = cos(radians(theta)), sin(radians(theta))
        a = (center[0]-first[0])*ux+(center[1]-first[1])*uy
        if len(track.observations) == 1:
            a = min(self.parameters["advance"], 0.8*a)
        a = max(1.0, a)
        b = max(15.0, min(self.parameters["offset"], radius*0.13), a*tan(radians(ERROR_DEG))+1)
        plus = (first[0]+a*ux-b*uy, first[1]+a*uy+b*ux)
        minus = (first[0]+a*ux+b*uy, first[1]+a*uy-b*ux)
        c, s = cos(radians(ERROR_DEG)), sin(radians(ERROR_DEG))
        three_disk_safe = (hypot(a,b) <= 999.999999 and
                           hypot(a-1000*c,b+1000*s) <= 999.999999)
        local_safe = all(max(dist(q,p) for p in track.polygon) <= 999.999999 for q in (plus,minus))
        if not (three_disk_safe or local_safe):
            return None
        probes = (plus, minus) if track.channel % 2 else (minus, plus)
        first_result = self.measure(probes[0], track)["measure_result"]
        if first_result != "no_signal":
            return first_result
        second_result = self.measure(probes[1], track)["measure_result"]
        if second_result == "no_signal":
            tightened = clip(track.polygon, ux, uy, ux*first[0]+uy*first[1]+a)
            if not tightened:
                raise RuntimeError("成对探测约束与已有观测矛盾")
            track.polygon, track._circle = tightened, None
            track.paired_radial_cuts += 1
            return "radial_cut"
        return second_result

    def localize(self, track):
        losses = 0
        for attempt in range(12):
            if track.near is not None:
                if self.clear(track.near, track):
                    return
                raise RuntimeError("near 后原地清除失败：反馈与题面规则不一致")
            center, radius = track.circle()
            threshold = {"baseline": 19.0, "adaptive": 45.0}.get(self.branch, self.parameters["clear_radius"])
            if radius <= threshold and not any(dist(center, p) < 3 for p in track.failed_clears):
                if self.clear(center, track):
                    return
                if not any(dist(center, p) < 1e-6 for p, _ in track.observations):
                    response = self.measure(center, track)
                    losses += response["measure_result"] == "no_signal"
                    continue
            if losses >= 3 or track.geometry_resets:
                break
            if self.problem == 4 and self.branch in ("paired", "joint", "agile", "relay", "stereo", "orbit", "weave", "portfolio"):
                if self.paired_probe(track) is not None:
                    continue
            point = self.probe(track, attempt, losses)
            response = self.measure(point, track)
            if response["measure_result"] == "no_signal":
                losses += 1
        self.fallbacks += 1
        points = optical_cover(track.polygon)
        # A serpentine sweep has a bounded travel length and covers every cell.
        if dist(self.api.position, points[-1]) < dist(self.api.position, points[0]):
            points.reverse()
        for point in points:
            if any(dist(point, p) < 1e-6 for p in track.failed_clears):
                continue
            if self.clear(point, track):
                return
        raise RuntimeError("完整候选区域光学覆盖后仍未找到源：停止并保留日志")

    def run(self):
        started = time.perf_counter()
        if not self.api.entered:
            self.api.enter()
        complete = False
        try:
            self.scan((0.0, 0.0))
            while True:
                known = self.known_pending()
                if not known:
                    if len(self.api.cleared) == 16:
                        complete, self.reason = True, "population_upper_bound_16"
                        break
                    if self.coverage.complete:
                        complete, self.reason = True, self.coverage.reason
                        break
                    point = self.coverage.next_station(self.api.position, self.branch, len(self.unknown()))
                    self.scan(point)
                    continue
                self.bystanders()
                known = self.known_pending()
                track = min(known, key=lambda t: dist(self.api.position, t.circle()[0]))
                scan_goals=set()
                if self.branch in ("joint", "agile", "relay", "stereo", "orbit", "weave", "portfolio"):
                    events = [(t.circle()[0], t) for t in known]
                    if not self.coverage.complete and self.unknown() and sum(t.known for t in self.tracks.values()) < 16:
                        anchors = [p for i,p in enumerate(self.coverage.anchors) if i not in self.coverage.visited]
                        if self.branch == "agile":
                            from .dynamic_cover import prune_anchors
                            anchors=prune_anchors(self.api.position,self.coverage.positions,
                                                  [p for p,t in events],anchors,self.problem)
                        if self.branch == "weave":
                            from .dynamic_cover import scan_plan
                            anchors,scan_goals=scan_plan(self.api.position,self.coverage.positions,
                                                         [p for p,t in events],anchors,self.problem,len(self.unknown()))
                        events += [(p,None) for p in anchors]
                    if self.branch=="portfolio":
                        from .routing import portfolio_route
                        self.warm_route=portfolio_route(self.api.position,[p for p,t in events],self.warm_route,self.parameters["route_starts"])
                        first_event=self.warm_route[0]
                    else:
                        first_event = shortest_open_route(self.api.position, [p for p,t in events])[0]
                    next_point, chosen_track = next(e for e in events if e[0] == first_event)
                    if chosen_track is None:
                        self.scan(next_point)
                        continue
                    track = chosen_track
                scan_after=track.circle()[0] in scan_goals
                self.localize(track)
                if self.branch == "weave" and self.unknown() and sum(t.known for t in self.tracks.values()) < 16:
                    if scan_after:
                        self.scan(self.api.position)
                    from .dynamic_cover import covers
                    if covers(self.coverage.positions,self.problem):
                        self.coverage.complete,self.coverage.reason=True,"continuous_dynamic_cover"
                elif self.branch == "agile" and self.unknown() and sum(t.known for t in self.tracks.values()) < 16:
                    if min(dist(self.api.position,p)for p in self.coverage.positions)>150:
                        self.scan(self.api.position)
                    from .dynamic_cover import covers
                    if covers(self.coverage.positions,self.problem):
                        self.coverage.complete,self.coverage.reason=True,"continuous_dynamic_cover"
                elif self.branch != "baseline" and self.unknown() and len(self.api.cleared) < 16:
                    threshold = 0.025 if self.branch == "adaptive" else self.parameters["scan_gain"]
                    if self.coverage.gain(self.api.position) >= threshold:
                        self.scan(self.api.position)
        except BudgetExceeded as exc:
            self.reason = str(exc)
        if not self.api.exited:
            try:
                self.api.exit()
            except BudgetExceeded:
                pass
        return {"problem": self.problem, "branch": self.branch, "complete_certificate": complete,
                "stop_reason": self.reason, "cleared_channels": sorted(self.api.cleared),
                "virtual_time_s": self.api.virtual_time, "actions": dict(self.api.counts),
                "coverage_scan_stops": self.scan_stops, "fixed_anchors": len(self.coverage.anchors),
                "optical_fallbacks": self.fallbacks,
                "geometry_resets": sum(t.geometry_resets for t in self.tracks.values()),
                "paired_radial_cuts": sum(t.paired_radial_cuts for t in self.tracks.values()),
                "parameters": self.parameters,
                "policy_runtime_s": time.perf_counter()-started}

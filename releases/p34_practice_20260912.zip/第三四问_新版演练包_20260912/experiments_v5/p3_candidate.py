"""Frozen P3 candidate selected using train_v5 only; target not yet met."""
from experiments_v5.p3_probe_geometry import ContinuousPolicy


class SearchPolicy(ContinuousPolicy):
    algorithm_version='problem3_v5_continuous'

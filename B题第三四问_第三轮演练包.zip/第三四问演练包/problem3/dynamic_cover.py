"""Conservative continuous certificates for scan points chosen along a route."""
from math import cos, sin, pi, hypot
from .geometry import hull, dist


def covers(points, problem, max_depth=12):
    points = tuple(set(points))
    if len(points) < (5 if problem == 3 else 6):
        return False
    radius2 = 999.999**2

    def box_ok(x0,y0,x1,y1):
        nearby = [s for s in points if max(abs(s[0]-x0),abs(s[0]-x1))**2
                  + max(abs(s[1]-y0),abs(s[1]-y1))**2 <= radius2]
        if problem == 3:
            return bool(nearby)
        if len(nearby) < 3:
            return False
        h = hull(nearby)
        if len(h) < 3:
            return False
        for a,b in zip(h,h[1:]+h[:1]):
            dx,dy = b[0]-a[0],b[1]-a[1]
            x,y = (x0 if -dy >= 0 else x1),(y0 if dx >= 0 else y1)
            if dx*(y-a[1])-dy*(x-a[0]) < 1e-5*max(1,hypot(dx,dy)):
                return False
        return True

    # Samples only reject a candidate; acceptance requires whole-box coverage.
    for radius in ((1800,) if problem == 3 else (900,1300,1800)):
        for k in range(36):
            x,y=radius*cos(k*pi/18),radius*sin(k*pi/18)
            if not box_ok(x,y,x,y):
                return False
    pending=[(-1800.,-1800.,1800.,1800.,0)]
    boxes=0
    while pending:
        boxes+=1
        if boxes>8000:
            return False  # A computation limit must never imply coverage.
        x0,y0,x1,y1,d=pending.pop()
        if hypot(max(x0,min(0,x1)),max(y0,min(0,y1))) > 1800.000001:
            continue
        if box_ok(x0,y0,x1,y1):
            continue
        if d >= max_depth:
            return False
        xm,ym=(x0+x1)/2,(y0+y1)/2
        pending.extend((a,b,c,e,d+1) for a,b,c,e in
                       ((x0,y0,xm,ym),(xm,y0,x1,ym),(x0,ym,xm,y1),(xm,ym,x1,y1)))
    return True


def prune_anchors(position, observed, goals, anchors, problem):
    """Pruning affects the planned route only. Actual stopping is checked again."""
    pending=list(anchors)
    fixed=list(observed)+list(goals)
    if not goals:
        return pending
    order=sorted(pending,key=lambda a:min(dist(a,g)for g in fixed),reverse=True)
    for p in order:
        trial=[a for a in pending if a != p]
        if covers(fixed+trial,problem):
            pending=trial
    return pending


def scan_plan(position,observed,goals,anchors,problem,unknown_count):
    """Backward elimination prices scan time and insertion distance together."""
    from .coverage import shortest_open_route
    planned=list(anchors)+list(goals)
    route=shortest_open_route(position,list(dict.fromkeys(planned)))
    travel={}
    for i,p in enumerate(route):
        a=position if i==0 else route[i-1]
        delta=dist(a,p)
        if i+1<len(route):
            b=route[i+1]
            delta+=dist(p,b)-dist(a,b)
        travel[p]=delta/5 if p in anchors else 0
    ordered=sorted(planned,key=lambda p:travel[p]+6*unknown_count,reverse=True)
    for p in ordered:
        if problem==4 and hypot(*p)>1800:
            continue
        trial=list(planned)
        trial.remove(p)
        if covers(list(observed)+trial,problem):
            planned=trial
    return [p for p in anchors if p in planned],set(p for p in goals if p in planned)

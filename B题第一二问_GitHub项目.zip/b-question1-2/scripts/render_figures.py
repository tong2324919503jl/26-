"""生成静态数学示意图。可选依赖：matplotlib（包含 numpy）。

所有配置缓存、临时文件、SVG 和 PNG 均写入项目内部。
"""

from __future__ import annotations

import csv
import json
import math
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
for name in ("matplotlib", "tmp"):
    (ROOT / ".cache" / name).mkdir(parents=True, exist_ok=True)
os.environ["MPLCONFIGDIR"] = str(ROOT / ".cache/matplotlib")
os.environ["TEMP"] = str(ROOT / ".cache/tmp")
os.environ["TMP"] = str(ROOT / ".cache/tmp")
os.environ["XDG_CACHE_HOME"] = str(ROOT / ".cache")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Circle, Polygon, Wedge
import numpy as np

from b12.geometry import Bearing
from b12.selection import DiameterBoundEvaluator, first_region_outer

FIGURES = ROOT / "docs/figures"
FIGURES.mkdir(parents=True, exist_ok=True)
font_paths = [
    Path("C:/Windows/Fonts/msyh.ttc"),
    Path("/System/Library/Fonts/PingFang.ttc"),
    Path("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"),
]
for font in font_paths:
    if font.exists():
        font_manager.fontManager.addfont(str(font))
        plt.rcParams["font.family"] = font_manager.FontProperties(fname=str(font)).get_name()
        break
plt.rcParams.update({
    "axes.unicode_minus": False, "font.size": 11, "axes.titlesize": 14,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.grid": True, "grid.alpha": 0.18,
    "svg.fonttype": "path", "figure.facecolor": "white",
})


def read_result(name):
    return json.loads((ROOT / "results" / f"{name}.json").read_text(encoding="utf-8"))


def save(figure, name):
    figure.savefig(FIGURES / f"{name}.svg", bbox_inches="tight")
    figure.savefig(FIGURES / f"{name}.png", dpi=180, bbox_inches="tight")
    plt.close(figure)
    print(f"Saved {name}", flush=True)


def triangle_figure():
    figure, axes = plt.subplots(1, 2, figsize=(13.8, 5.8), layout="constrained")
    data = json.loads((ROOT / "examples/q1_triangle.json").read_text(encoding="utf-8"))
    triangle = np.array([[0, 0], [40, 0], [20, 20 * math.sqrt(3)]])
    colors = ["#2e6e9e", "#9366a3", "#ba8231"]
    for i, (r, color) in enumerate(zip(data["readings"], colors), 1):
        axes[0].add_patch(Wedge((r["x"], r["y"]), 1200,
                               r["bearing_deg"] - 1, r["bearing_deg"] + 1,
                               facecolor=color, alpha=0.3, edgecolor=color))
        axes[0].scatter(r["x"], r["y"], color=color, s=32)
        axes[0].annotate(f"S{i}   {r['bearing_deg']:.0f}°",
                         (r["x"], r["y"]), xytext=(7, 9), textcoords="offset points")
    axes[0].add_patch(Polygon(triangle, facecolor="#db5d50", edgecolor="#9d2928", zorder=5))
    axes[0].annotate("交集为边长 40 m 的等边三角形", (20, 15), xytext=(-730, -480),
                     arrowprops={"arrowstyle": "->", "color": "#555"})
    axes[0].set(xlim=(-1180, 850), ylim=(-1060, 1130),
                title="三组有效的 ±1° 示向观测", xlabel="x / m", ylabel="y / m")
    axes[0].set_aspect("equal")
    ax = axes[1]
    ax.add_patch(Polygon(triangle, facecolor="#f4c7bd", edgecolor="#b34735", alpha=0.7, label="定位区域"))
    ax.add_patch(Circle((20, 0), 20, fill=False, linestyle="--", lw=2.0, edgecolor="#c64848", label="直径 40 m 的圆"))
    center = (20, 20 * math.sqrt(3) / 3)
    radius = 40 / math.sqrt(3)
    ax.add_patch(Circle(center, radius, fill=False, lw=2.2, edgecolor="#178775", label="最小包围圆"))
    ax.scatter(*center, color="#178775", marker="+", s=85)
    for name, point, offset in zip(("A", "B", "C"), triangle, ((-16, -15), (7, -15), (6, 5))):
        ax.scatter(*point, color="#9d2928", s=25)
        ax.annotate(name, point, xytext=offset, textcoords="offset points")
    ax.text(20, 11.5, "r* = 23.094 m", ha="center", va="bottom", color="#116c5f",
            bbox={"facecolor": "white", "edgecolor": "none", "alpha": 0.8, "pad": 2})
    ax.set(xlim=(-11, 53), ylim=(-24, 45), title="区域直径 40 m，但半径 20 m 不足以覆盖",
           xlabel="x / m", ylabel="y / m")
    ax.set_aspect("equal")
    ax.legend(loc="lower center", fontsize=10)
    save(figure, "q1_counterexample")


def candidate_figure():
    figure, ax = plt.subplots(figsize=(9, 7.5), layout="constrained")
    x = np.linspace(-100, 1550, 661)
    y = np.linspace(-1080, 1080, 865)
    xx, yy = np.meshgrid(x, y)
    d = math.radians(1)
    c, s = 1000 * math.cos(d), 1000 * math.sin(d)
    safe = (xx ** 2 + yy ** 2 <= 1000 ** 2) & ((xx - c) ** 2 + (yy - s) ** 2 <= 1000 ** 2) & ((xx - c) ** 2 + (yy + s) ** 2 <= 1000 ** 2)
    direction = safe & (np.abs(yy) * math.cos(d) - xx * math.sin(d) > 5)
    layer = np.where(direction, 2.0, np.where(safe, 1.0, np.nan))
    ax.contourf(xx, yy, layer, levels=[0.5, 1.5, 2.5], colors=["#dfedf0", "#8bc8cf"], alpha=0.8)
    for i, center in enumerate(((0, 0), (c, s), (c, -s))):
        ax.add_patch(Circle(center, 1000, fill=False, lw=1.05,
                            linestyle="--", color=("#647888" if i == 0 else "#aa956e"),
                            label="三个圆盘的边界" if i == 0 else None))
    ax.add_patch(Wedge((0, 0), 1500, -1, 1, facecolor="#ea9c79", alpha=0.8, label="首次可能方位"))
    result = read_result("q2_origin")
    a, b = result["selected_local_m"]
    ax.scatter(a, b, s=155, marker="*", color="#a22c2b", zorder=8, label="数值选点")
    ax.plot([0, a], [0, b], color="#a22c2b", lw=1.3)
    ax.scatter(800, -600, color="#236c88", s=40, label="简明候选 (800, −600)")
    ax.annotate(f"({a:.1f}, {b:.1f}) m", (a, b), xytext=(20, 17), textcoords="offset points")
    ax.scatter(0, 0, color="#283c4a", s=35, zorder=9)
    ax.annotate("首次检测点 S", (0, 0), xytext=(-10, -25), textcoords="offset points")
    ax.text(430, -420, "可接收且保证正常测向\n的候选区域", ha="center", color="#244f57")
    ax.set(xlim=(-170, 1570), ylim=(-1080, 1080),
           xlabel="a / m（沿首次示向方向）", ylabel="b / m（横向）",
           title="三个圆盘交集，进一步排除首次扇形附近 5 m")
    ax.set_aspect("equal")
    ax.legend(loc="lower right", framealpha=0.95, fontsize=10)
    save(figure, "q2_candidate_region")


def comparison_figure():
    grid = read_result("validation_grid")
    result = read_result("q2_origin")
    rows = grid["rows"]
    figure, axes = plt.subplots(1, 2, figsize=(14.3, 5.8), layout="constrained")
    labels = ["沿示向前进 750 m", "横移 750 m（可能无信号）", "45° 方向移动 1000 m", "安全点 (800,600)", "本文选点"]
    values = [row["direction_only_diameter_upper_m"] for row in rows]
    bars = axes[0].barh(labels, values, color=["#b5c3cc", "#d1d1d1", "#7fadc5", "#528fae", "#178775"], height=0.6)
    bars[1].set_hatch("//")
    axes[0].invert_yaxis()
    for bar, value in zip(bars, values):
        axes[0].text(value + 9, bar.get_y() + bar.get_height() / 2, f"{value:.2f}", va="center", fontsize=10)
    axes[0].set(xlim=(0, 875), xlabel="定位直径上界 / m（有示向度分支）", title="相同首次观测下的策略比较")
    axes[0].text(0.02, -0.18, "横移策略仅 563 / 1281 个源位置可接收；\n其他四种策略均满足全向源可接收保证。",
                 transform=axes[0].transAxes, fontsize=10, color="#555")

    evaluator = DiameterBoundEvaluator(first_region_outer(Bearing(0, 0, 0)), 1.0, 0.1)
    angles = np.arange(15.0, 59.001, 0.5)
    bounds = []
    for beta in angles:
        p = 1000 * math.cos(math.radians(beta)), 1000 * math.sin(math.radians(beta))
        bounds.append(evaluator.evaluate(p).diameter_upper_m)
    a, b = result["selected_local_m"]
    beta = abs(math.degrees(math.atan2(b, a)))
    axes[1].plot(angles, bounds, color="#24667d", lw=2)
    axes[1].scatter(beta, result["worst_diameter_upper_m"], marker="*", s=150, color="#a22c2b", zorder=5)
    axes[1].annotate(f"选点：β = {beta:.2f}°\n上界 {result['worst_diameter_upper_m']:.2f} m",
                     (beta, result["worst_diameter_upper_m"]),
                     xytext=(beta + 4, result["worst_diameter_upper_m"] + 24),
                     arrowprops={"arrowstyle": "->", "color": "#777"}, fontsize=10)
    axes[1].set(xlabel="移动方向相对首次示向度的偏转角 β / °",
                ylabel="定位直径上界 / m", title="移动距离固定 1000 m 时的角度比较")
    with (ROOT / "results/q2_angle_sweep.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["beta_deg", "movement_m", "diameter_upper_m", "angle_grid_step_deg"])
        writer.writerows((float(beta), 1000, float(bound), 0.1) for beta, bound in zip(angles, bounds))
    save(figure, "q2_comparison")


def main():
    triangle_figure()
    candidate_figure()
    comparison_figure()


if __name__ == "__main__":
    main()

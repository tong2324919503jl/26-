"""Exact rational verification of a finite, continuous directional discovery cover."""
from __future__ import annotations

from fractions import Fraction as F
from functools import lru_cache
import hashlib
import json
from math import cos, pi, sin


def ring_stations():
    return ((0.0, 0.0),) + tuple((990*cos(k*2*pi/7), 990*sin(k*2*pi/7)) for k in range(7)) + tuple(
        (1850*cos(k*pi/7), 1850*sin(k*pi/7)) for k in range(14))


def exact_hull(points):
    points = sorted(set(points))
    def cross(a, b, c):
        return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
    lower, upper = [], []
    for seq, out in ((points, lower), (reversed(points), upper)):
        for p in seq:
            while len(out) > 1 and cross(out[-2], out[-1], p) <= 0:
                out.pop()
            out.append(p)
    return lower[:-1]+upper[:-1]


def build_certificate(stations=None, max_depth=17):
    stations = tuple(stations or ring_stations())
    rational = [tuple(F(x) for x in p) for p in stations]
    leaves, deepest = [], 0

    @lru_cache(maxsize=None)
    def local_hull(indices):
        return exact_hull([rational[i] for i in indices])

    def covered(box):
        x0, y0, x1, y1 = box
        indices = tuple(i for i, s in enumerate(stations)
                        if max(abs(s[0]-x0), abs(s[0]-x1))**2
                        + max(abs(s[1]-y0), abs(s[1]-y1))**2 <= 999.99999**2)
        if len(indices) < 3:
            return None
        corners = [(F(x), F(y)) for x, y in ((x0,y0),(x1,y0),(x1,y1),(x0,y1))]
        # Every claimed distance and halfplane predicate is checked exactly.
        for i in indices:
            sx, sy = rational[i]
            if any((sx-x)**2+(sy-y)**2 > 1000**2 for x, y in corners):
                return None
        h = local_hull(indices)
        if len(h) < 3:
            return None
        for a, b in zip(h, h[1:]+h[:1]):
            for x, y in corners:
                if (b[0]-a[0])*(y-a[1])-(b[1]-a[1])*(x-a[0]) < 0:
                    return None
        return indices

    pending = [((-1800.0,-1800.0,1800.0,1800.0), "")]
    while pending:
        box, path = pending.pop()
        x0,y0,x1,y1 = box
        nearest_x, nearest_y = F(max(x0, min(0, x1))), F(max(y0, min(0, y1)))
        if nearest_x**2+nearest_y**2 > 1800**2:
            leaves.append({"path": path, "outside_target_disk": True})
            continue
        indices = covered(box)
        if indices is not None:
            leaves.append({"path": path, "witness_stations": list(indices)})
            deepest = max(deepest, len(path))
            continue
        if len(path) >= max_depth:
            return {"verified": False, "unresolved_box": box, "depth": len(path)}
        xm,ym = (x0+x1)/2,(y0+y1)/2
        for k, child in enumerate(((x0,y0,xm,ym),(xm,y0,x1,ym),(x0,ym,xm,y1),(xm,ym,x1,y1))):
            pending.append((child, path+str(k)))
    encoded = json.dumps(stations, separators=(",", ":")).encode()
    return {"verified": True, "arithmetic": "exact Fraction of stored coordinates",
            "target_radius_m": 1800, "minimum_reception_radius_m": 1000,
            "stations": stations, "station_sha256": hashlib.sha256(encoded).hexdigest(),
            "leaf_count": len(leaves), "maximum_covered_depth": deepest, "leaves": leaves}


def verify_certificate(document):
    """Independently replay every leaf and verify that the leaves partition the root."""
    if not document.get("verified"):
        return False
    stations = [tuple(F(x) for x in p) for p in document["stations"]]
    leaves = document["leaves"]
    paths = {leaf["path"] for leaf in leaves}
    if len(paths) != len(leaves) or sum(F(1, 4**len(p)) for p in paths) != 1:
        return False
    if any(p[:k] in paths for p in paths for k in range(len(p))):
        return False
    for leaf in leaves:
        x0,y0,x1,y1 = map(F, (-1800,-1800,1800,1800))
        for char in leaf["path"]:
            if char not in "0123":
                return False
            xm,ym = (x0+x1)/2,(y0+y1)/2
            x0,y0,x1,y1 = ((x0,y0,xm,ym),(xm,y0,x1,ym),(x0,ym,xm,y1),(xm,ym,x1,y1))[int(char)]
        if leaf.get("outside_target_disk"):
            if max(x0,min(0,x1))**2+max(y0,min(0,y1))**2 <= 1800**2:
                return False
            continue
        points = [stations[i] for i in leaf["witness_stations"]]
        corners = [(x0,y0),(x1,y0),(x1,y1),(x0,y1)]
        if any((x-a)**2+(y-b)**2 > 1000**2 for x,y in corners for a,b in points):
            return False
        h = exact_hull(points)
        if len(h) < 3:
            return False
        if any((b[0]-a[0])*(y-a[1])-(b[1]-a[1])*(x-a[0]) < 0
               for a,b in zip(h,h[1:]+h[:1]) for x,y in corners):
            return False
    return True


if __name__ == "__main__":
    from .protocol import output_path
    path = output_path("problem4/results/coverage_certificate.json")
    result = build_certificate()
    result["independently_replayed"] = verify_certificate(result)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    print(json.dumps({k:v for k,v in result.items() if k not in ("leaves", "stations")}, indent=2))

"""Serial protocol client. HTTP is enabled only by explicit rehearsal confirmation."""
from __future__ import annotations

import json
import math
from pathlib import Path
import time
import unicodedata
from urllib.error import HTTPError, URLError
from urllib.request import ProxyHandler, Request, build_opener
import uuid

PROJECT_ROOT = Path(__file__).resolve().parent.parent


class ActionRejected(RuntimeError):
    pass


class BudgetExceeded(RuntimeError):
    pass


class UncertainAction(RuntimeError):
    pass


def output_path(value):
    p = Path(value)
    if not p.is_absolute():
        p = PROJECT_ROOT / p
    p = p.resolve()
    if not p.is_relative_to(PROJECT_ROOT):
        raise ValueError("输出只能写入当前项目目录内")
    return p


def validate_id(value, limit):
    if (not isinstance(value, str) or not 1 <= len(value.encode("utf-8")) <= limit
            or any(unicodedata.category(c) in ("Cc", "Cf", "Cs") for c in value)):
        raise ValueError("队号/请求编号格式不合法")


def confirm_rehearsal(problem):
    expected = f"问题{problem}演练测试"
    print(f"请在模拟器界面确认当前为“{expected}”，并且接口已经就绪。")
    print("接口本身不能识别演练/正式模式；未核对界面请退出本程序。")
    answer = input(f"核对后请完整输入“{expected}”：").strip()
    if answer != expected:
        raise ValueError("未确认演练模式，没有发送任何网络请求")
    return {"problem": problem, "confirmed_label": answer, "confirmed_at": time.time()}


class HttpExchange:
    def __init__(self, port, confirmation, timeout=4.0):
        if (confirmation.get("problem") not in (3, 4)
                or confirmation.get("confirmed_label") != f"问题{confirmation['problem']}演练测试"):
            raise ValueError("需要人工核对演练模式")
        if not isinstance(port, int) or not 1 <= port <= 65535:
            raise ValueError("端口必须在 1..65535")
        self.base = f"http://127.0.0.1:{port}"
        self.confirmation = dict(confirmation)
        self.timeout = timeout
        self.opener = build_opener(ProxyHandler({}))

    def __call__(self, path, payload):
        if path not in ("/enter", "/measure", "/clear", "/exit"):
            raise ValueError("Unknown endpoint")
        body = json.dumps(payload, ensure_ascii=False, allow_nan=False, separators=(",", ":")).encode("utf-8")
        # A retry retains identical bytes, endpoint, and request_id.
        for attempt in range(3):
            req = Request(self.base+path, data=body, method="POST",
                          headers={"Content-Type": "application/json; charset=utf-8"})
            try:
                with self.opener.open(req, timeout=self.timeout) as response:
                    status = response.status
                    result = json.loads(response.read().decode("utf-8"))
                if status != 200:
                    raise ActionRejected(f"HTTP {status}")
                return result
            except HTTPError as exc:
                detail = exc.read().decode("utf-8", errors="replace")
                raise ActionRejected(f"HTTP {exc.code}: {detail}") from exc
            except (URLError, TimeoutError, ConnectionError, OSError, json.JSONDecodeError) as exc:
                if attempt == 2:
                    raise UncertainAction(
                        f"动作 {payload['request_id']} 响应不确定；已保留原ID重试，停止发送新动作。"
                    ) from exc
                time.sleep(0.15*(attempt+1))
        raise AssertionError("Unreachable")


class Client:
    """Policy-facing object: public observations only, no source truth."""
    def __init__(self, exchange, robot_id="offline-team", journal=None, real_guard=True):
        validate_id(robot_id, 64)
        self._exchange = exchange
        self.robot_id = robot_id
        self.run_id = uuid.uuid4().hex[:16]
        self.sequence = 0
        self.position = (0.0, 0.0)
        self.channel = 1
        self.virtual_time = 0.0
        self.deadline = float("inf")
        self.max_virtual = 360000.0
        self.real_guard = real_guard
        self.entered = self.exited = False
        self.cleared = set()
        self.counts = {"measure": 0, "clear": 0, "clear_success": 0, "no_signal": 0}
        self.history = []
        self.journal = output_path(journal) if journal else None
        if self.journal:
            self.journal.parent.mkdir(parents=True, exist_ok=True)
            if self.journal.exists():
                raise ValueError("日志已存在；请使用新的输出目录，避免覆盖历史动作")

    def _log(self, record):
        self.history.append(record)
        if self.journal:
            with self.journal.open("a", encoding="utf-8") as f:
                f.write(json.dumps(record, ensure_ascii=False, allow_nan=False)+"\n")

    def _call(self, path, position=None, channel=None):
        if path != "/enter":
            if not self.entered or self.exited:
                raise ActionRejected("Client session is not active")
            if self.real_guard and time.monotonic() >= self.deadline - (2 if path == "/exit" else 15):
                raise BudgetExceeded("现实运行预算不足")
        if position is not None:
            position = tuple(float(v) for v in position)
            if len(position) != 2 or any(not math.isfinite(v) or abs(v) > 2000000 for v in position):
                raise ValueError("Invalid position")
            if isinstance(channel, bool) or not isinstance(channel, int) or not 1 <= channel <= 20:
                raise ValueError("Invalid channel")
            estimated = math.dist(self.position, position)/5+6
            if self.virtual_time+estimated >= self.max_virtual:
                raise BudgetExceeded("虚拟运行预算不足")
        self.sequence += 1
        payload = {"arena_id": "default", "robot_id": self.robot_id,
                   "request_id": f"{self.run_id}-{self.sequence}"}
        if position is not None:
            payload.update(position={"x": position[0], "y": position[1]}, channel=channel)
        self._log({"event": "intent", "path": path, "payload": payload})
        started = time.monotonic()
        response = self._exchange(path, payload)
        self._log({"event": "response", "request_id": payload["request_id"],
                   "response": response, "round_trip_s": time.monotonic()-started})
        if response.get("accepted") is not True:
            raise ActionRejected("动作未被接受；保留此前位置、频道和虚拟时间")
        virtual = response.get("virtual_time_s")
        if isinstance(virtual, bool) or not isinstance(virtual, (int, float)) or not math.isfinite(virtual):
            raise ActionRejected("Malformed accepted response")
        if virtual+1e-6 < self.virtual_time:
            raise ActionRejected("Server virtual time moved backwards")
        if path == "/measure":
            status = response.get("measure_result")
            if status not in ("direction", "near", "no_signal"):
                raise ActionRejected("Unknown measure result")
            if status == "direction":
                angle = response.get("svd_deg")
                if isinstance(angle, bool) or not isinstance(angle, (int, float)) or not 0 <= angle < 360:
                    raise ActionRejected("Invalid bearing response")
            self.position, self.channel = position, channel
            self.counts["measure"] += 1
            self.counts["no_signal"] += status == "no_signal"
        elif path == "/clear":
            if response.get("clear_result") not in ("success", "no_target_in_range"):
                raise ActionRejected("Unknown clear result")
            self.position = position
            self.counts["clear"] += 1
            if response["clear_result"] == "success":
                self.cleared.add(channel)
                self.counts["clear_success"] += 1
        elif path == "/enter":
            remaining = response.get("remaining_real_duration_s")
            if isinstance(remaining, bool) or not isinstance(remaining, (int, float)) or not 0 <= remaining <= 1200:
                raise ActionRejected("Missing/invalid remaining_real_duration_s")
            self.deadline = started+remaining
            self.max_virtual = float(response["max_virtual_duration_s"])
            self.entered = True
        elif path == "/exit":
            self.exited = True
        self.virtual_time = float(virtual)
        return response

    def enter(self):
        return self._call("/enter")

    def measure(self, position, channel):
        return self._call("/measure", position, channel)

    def clear(self, position, channel):
        return self._call("/clear", position, channel)

    def exit(self):
        return self._call("/exit")

"""二维凸几何：不使用人为截断框判断无界定位区域。

长度单位为米，角度输入为度。浮点容差不是区间算术证明。
"""

from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations
from math import cos, hypot, inf, isfinite, pi, radians, sin
from typing import Iterable, Sequence

Point = tuple[float, float]
LENGTH_EPS = 1e-8
ANGLE_EPS = 2e-14


def sub(p: Point, q: Point) -> Point:
    return p[0] - q[0], p[1] - q[1]


def dot(p: Point, q: Point) -> float:
    return p[0] * q[0] + p[1] * q[1]


def cross(p: Point, q: Point) -> float:
    return p[0] * q[1] - p[1] * q[0]


def distance(p: Point, q: Point) -> float:
    return hypot(p[0] - q[0], p[1] - q[1])


def unit(degrees: float) -> Point:
    a = radians(degrees % 360.0)
    return cos(a), sin(a)


@dataclass(frozen=True)
class Bearing:
    x: float
    y: float
    bearing_deg: float
    error_deg: float = 1.0

    def __post_init__(self) -> None:
        if not all(isfinite(v) for v in (self.x, self.y, self.bearing_deg, self.error_deg)):
            raise ValueError("检测坐标、示向度和误差须为有限数值")
        if not 0.0 < self.error_deg < 90.0:
            raise ValueError("误差半角须严格位于 (0, 90) 度内")

    @property
    def position(self) -> Point:
        return self.x, self.y


@dataclass(frozen=True)
class HalfPlane:
    """闭半平面 a*x + b*y <= c。"""

    a: float
    b: float
    c: float

    def normalized(self) -> HalfPlane:
        n = hypot(self.a, self.b)
        if not all(isfinite(v) for v in (self.a, self.b, self.c)) or n == 0.0:
            raise ValueError("半平面法向量须非零，所有系数须有限")
        return HalfPlane(self.a / n, self.b / n, self.c / n)

    def value(self, p: Point) -> float:
        return self.a * p[0] + self.b * p[1] - self.c

    def contains(self, p: Point, eps: float = LENGTH_EPS) -> bool:
        return self.value(p) <= eps


def bearing_halfplanes(reading: Bearing) -> tuple[HalfPlane, HalfPlane]:
    """两条边界共同约束前向扇形，不是整条示向直线的误差带。"""
    lower = unit(reading.bearing_deg - reading.error_deg)
    upper = unit(reading.bearing_deg + reading.error_deg)
    n1 = lower[1], -lower[0]
    n2 = -upper[1], upper[0]
    return (
        HalfPlane(*n1, dot(n1, reading.position)),
        HalfPlane(*n2, dot(n2, reading.position)),
    )


def feasible_point(planes: Sequence[HalfPlane]) -> Point | None:
    """增量可行性判定，最坏 O(m²)，亦适用于条带、直线和单点。"""
    p: Point = (0.0, 0.0)
    for i, plane in enumerate(planes):
        if plane.contains(p):
            continue
        # 新约束被违反；若交集非空，它在新边界上必有可行点。
        origin = plane.a * plane.c, plane.b * plane.c
        tangent = -plane.b, plane.a
        lower, upper = -inf, inf
        for previous in planes[:i]:
            coefficient = previous.a * tangent[0] + previous.b * tangent[1]
            rhs = previous.c - previous.a * origin[0] - previous.b * origin[1]
            if abs(coefficient) <= ANGLE_EPS:
                if rhs < -LENGTH_EPS:
                    return None
            elif coefficient > 0:
                upper = min(upper, rhs / coefficient)
            else:
                lower = max(lower, rhs / coefficient)
        if lower > upper + LENGTH_EPS:
            return None
        t = max(lower, min(0.0, upper))
        p = origin[0] + t * tangent[0], origin[1] + t * tangent[1]
    return p


def recession_direction(planes: Sequence[HalfPlane]) -> Point | None:
    """寻找非零 d 使所有 n_i·d <= 0；找到即存在无界方向。"""
    if not planes:
        return 1.0, 0.0
    for plane in planes:
        for direction in ((-plane.b, plane.a), (plane.b, -plane.a)):
            if all(p.a * direction[0] + p.b * direction[1] <= ANGLE_EPS for p in planes):
                return direction
    return None


def convex_hull(points: Iterable[Point]) -> list[Point]:
    unique: list[Point] = []
    for p in sorted(points):
        if not any(distance(p, q) <= LENGTH_EPS for q in unique):
            unique.append(p)
    if len(unique) <= 2:
        return unique
    lower: list[Point] = []
    upper: list[Point] = []
    for p in unique:
        while len(lower) >= 2 and cross(sub(lower[-1], lower[-2]), sub(p, lower[-1])) <= 0:
            lower.pop()
        lower.append(p)
    for p in reversed(unique):
        while len(upper) >= 2 and cross(sub(upper[-1], upper[-2]), sub(p, upper[-1])) <= 0:
            upper.pop()
        upper.append(p)
    return lower[:-1] + upper[:-1]


@dataclass
class Region:
    status: str  # empty / unbounded / point / segment / polygon
    vertices: list[Point]
    witness: Point | None
    recession: Point | None = None


def intersect_halfplanes(planes: Iterable[HalfPlane]) -> Region:
    planes = [p.normalized() for p in planes]
    witness = feasible_point(planes)
    if witness is None:
        return Region("empty", [], None)
    direction = recession_direction(planes)
    if direction is not None:
        return Region("unbounded", [], witness, direction)
    vertices: list[Point] = []
    for first, second in combinations(planes, 2):
        determinant = first.a * second.b - first.b * second.a
        if abs(determinant) <= ANGLE_EPS:
            continue
        p = (
            (first.c * second.b - first.b * second.c) / determinant,
            (first.a * second.c - first.c * second.a) / determinant,
        )
        if all(h.contains(p) for h in planes):
            vertices.append(p)
    hull = convex_hull(vertices)
    if not hull:
        raise ArithmeticError("数值退化：可行且有界，但未恢复顶点，请缩放坐标或检查近乎平行的约束")
    status = {1: "point", 2: "segment"}.get(len(hull), "polygon")
    return Region(status, hull, witness)


def localize(readings: Sequence[Bearing]) -> Region:
    if not readings:
        raise ValueError("至少需要一个示向度观测")
    return intersect_halfplanes(h for reading in readings for h in bearing_halfplanes(reading))


def diameter_bruteforce(points: Sequence[Point]) -> tuple[float, tuple[Point, Point]]:
    if not points:
        raise ValueError("空集的直径在本程序中记为未定义")
    best = 0.0
    pair = points[0], points[0]
    for p, q in combinations(points, 2):
        d = distance(p, q)
        if d > best:
            best, pair = d, (p, q)
    return best, pair


def diameter_calipers(polygon: Sequence[Point]) -> tuple[float, tuple[Point, Point]]:
    """输入逆时针凸包；旋转卡壳 O(h)，处理平行支持边的平局。"""
    if len(polygon) <= 2:
        return diameter_bruteforce(polygon)
    count = len(polygon)
    j = 1
    best_squared = 0.0
    pair = polygon[0], polygon[0]

    def consider(i: int, k: int) -> None:
        nonlocal best_squared, pair
        difference = sub(polygon[i], polygon[k])
        squared = dot(difference, difference)
        if squared > best_squared:
            best_squared, pair = squared, (polygon[i], polygon[k])

    for i in range(count):
        next_i = (i + 1) % count
        edge = sub(polygon[next_i], polygon[i])

        def area(k: int) -> float:
            return cross(edge, sub(polygon[k], polygon[i]))

        advances = 0
        while area((j + 1) % count) > area(j) and advances < count:
            j = (j + 1) % count
            advances += 1
        consider(i, j)
        consider(next_i, j)
        if abs(area((j + 1) % count) - area(j)) <= LENGTH_EPS * max(1.0, hypot(*edge)):
            consider(i, (j + 1) % count)
            consider(next_i, (j + 1) % count)
    return best_squared ** 0.5, pair


@dataclass(frozen=True)
class Circle:
    center: Point
    radius: float

    def contains(self, p: Point) -> bool:
        return distance(self.center, p) <= self.radius + LENGTH_EPS


def circle_through_three(a: Point, b: Point, c: Point) -> Circle | None:
    u, v = sub(b, a), sub(c, a)
    determinant = 2.0 * cross(u, v)
    if abs(determinant) <= ANGLE_EPS * max(1.0, hypot(*u) * hypot(*v)):
        return None
    u2, v2 = dot(u, u), dot(v, v)
    offset = (u2 * v[1] - v2 * u[1]) / determinant, (u[0] * v2 - v[0] * u2) / determinant
    center = a[0] + offset[0], a[1] + offset[1]
    return Circle(center, hypot(*offset))


def minimum_enclosing_circle(points: Sequence[Point]) -> Circle:
    """枚举 1/2/3 个支撑点。确定性正确性清晰，最坏 O(h⁴)，适合少量检测点。

    此函数是第一问的附加分析，不参与第二问的高频选点评分。
    """
    hull = convex_hull(points)
    if not hull:
        raise ValueError("空集没有本程序定义的最小包围圆")
    if len(hull) == 1:
        return Circle(hull[0], 0.0)
    best = Circle(hull[0], inf)

    def consider(circle: Circle | None) -> None:
        nonlocal best
        if circle is not None and circle.radius < best.radius and all(circle.contains(p) for p in hull):
            best = circle

    for a, b in combinations(hull, 2):
        consider(Circle(((a[0] + b[0]) / 2.0, (a[1] + b[1]) / 2.0), distance(a, b) / 2.0))
    for a, b, c in combinations(hull, 3):
        consider(circle_through_three(a, b, c))
    if not isfinite(best.radius):
        raise ArithmeticError("未找到包围圆，请检查数值尺度")
    return best


def clip_polygon(polygon: Sequence[Point], plane: HalfPlane) -> list[Point]:
    """Sutherland-Hodgman 单半平面裁剪，支持退化的线段和点。"""
    if not polygon:
        return []
    output: list[Point] = []
    previous = polygon[-1]
    previous_value = plane.value(previous)
    previous_inside = previous_value <= LENGTH_EPS
    for current in polygon:
        current_value = plane.value(current)
        current_inside = current_value <= LENGTH_EPS
        if current_inside != previous_inside:
            denominator = previous_value - current_value
            if denominator != 0.0:
                t = min(1.0, max(0.0, previous_value / denominator))
                output.append((
                    previous[0] + t * (current[0] - previous[0]),
                    previous[1] + t * (current[1] - previous[1]),
                ))
        if current_inside:
            output.append(current)
        previous, previous_value, previous_inside = current, current_value, current_inside
    cleaned: list[Point] = []
    for p in output:
        if not cleaned or distance(p, cleaned[-1]) > LENGTH_EPS:
            cleaned.append(p)
    if len(cleaned) > 1 and distance(cleaned[0], cleaned[-1]) <= LENGTH_EPS:
        cleaned.pop()
    return cleaned


def clip_with_bearing(polygon: Sequence[Point], reading: Bearing) -> list[Point]:
    output = list(polygon)
    for plane in bearing_halfplanes(reading):
        output = clip_polygon(output, plane)
    return output


def outer_disk_polygon(center: Point, radius: float, sides: int = 360) -> list[Point]:
    """正多边形外包圆盘，边与圆相切；不是内接多边形。"""
    if not isfinite(radius) or radius <= 0 or sides < 8:
        raise ValueError("圆盘半径须为正有限数，外包多边形边数至少为 8")
    outer_radius = radius / cos(pi / sides)
    return [
        (center[0] + outer_radius * cos((2 * k + 1) * pi / sides),
         center[1] + outer_radius * sin((2 * k + 1) * pi / sides))
        for k in range(sides)
    ]


def intersect_disk_outer(polygon: Sequence[Point], center: Point, radius: float, sides: int = 360) -> list[Point]:
    output = list(polygon)
    for k in range(sides):
        nx, ny = cos(2 * pi * k / sides), sin(2 * pi * k / sides)
        output = clip_polygon(output, HalfPlane(nx, ny, nx * center[0] + ny * center[1] + radius))
        if not output:
            break
    return output


def polygon_area(polygon: Sequence[Point]) -> float:
    if len(polygon) < 3:
        return 0.0
    # 平移到首顶点后计算，减少大坐标相消。
    origin = polygon[0]
    return abs(sum(cross(sub(polygon[i], origin), sub(polygon[(i + 1) % len(polygon)], origin))
                   for i in range(len(polygon)))) / 2.0

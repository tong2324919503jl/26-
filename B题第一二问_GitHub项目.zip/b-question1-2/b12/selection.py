"""第二问：保证全向源可接收的候选区域，以及保守最坏直径选点。

算法只使用第一次观测。未知真值不会传入选点函数。
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from math import atan2, ceil, cos, degrees, hypot, isfinite, radians, sin
from typing import Callable, Sequence

from .geometry import (
    Bearing, HalfPlane, LENGTH_EPS, Point, bearing_halfplanes,
    clip_polygon, diameter_bruteforce, dot, intersect_disk_outer,
    outer_disk_polygon, unit,
)


def to_world(reading: Bearing, a: float, b: float) -> Point:
    ux, uy = unit(reading.bearing_deg)
    return reading.x + a * ux - b * uy, reading.y + a * uy + b * ux


def to_local(reading: Bearing, p: Point) -> Point:
    ux, uy = unit(reading.bearing_deg)
    dx, dy = p[0] - reading.x, p[1] - reading.y
    return dx * ux + dy * uy, -dx * uy + dy * ux


def signal_safe(a: float, b: float, error_deg: float = 1.0, radius_min: float = 1000.0) -> bool:
    """三个半径 R0 的圆盘交集；不把未知接收半径误当作固定 1000。"""
    angle = radians(error_deg)
    return (
        hypot(a, b) <= radius_min + LENGTH_EPS
        and hypot(a - radius_min * cos(angle), b - radius_min * sin(angle)) <= radius_min + LENGTH_EPS
        and hypot(a - radius_min * cos(angle), b + radius_min * sin(angle)) <= radius_min + LENGTH_EPS
    )


def bearing_clearance(a: float, b: float, error_deg: float = 1.0) -> float:
    """到首次无限扇形的外侧垂距；正数表示点位于扇形外。"""
    angle = radians(error_deg)
    return abs(b) * cos(angle) - a * sin(angle)


def candidate_allowed(a: float, b: float, error_deg: float = 1.0, radius_min: float = 1000.0) -> bool:
    return signal_safe(a, b, error_deg, radius_min) and bearing_clearance(a, b, error_deg) > 5.0 + LENGTH_EPS


def first_region_outer(
    reading: Bearing,
    radius_max: float = 1500.0,
    target_radius: float = 1800.0,
    circle_sides: int = 360,
) -> list[Point]:
    """首次可行集的外近似：首次扇形 ∩ 接收距离上界 ∩ 目标圆域。

    闭包包含距第一次检测点 <= 5 米的点，故为保守外近似。
    两个圆盘均外包，不能用内接多边形进行“保证性”评分。
    """
    if not isfinite(target_radius) or target_radius <= 0:
        raise ValueError("目标区域半径须为正有限数")
    polygon = outer_disk_polygon(reading.position, radius_max, circle_sides)
    for plane in bearing_halfplanes(reading):
        polygon = clip_polygon(polygon, plane)
    return intersect_disk_outer(polygon, (0.0, 0.0), target_radius, circle_sides)


@dataclass
class BoundResult:
    diameter_upper_m: float
    cell_center_deg: float
    angle_step_deg: float
    widened_error_deg: float
    worst_outer_polygon: list[Point]


class DiameterBoundEvaluator:
    """遍历角度网格，并将误差半角增大半个网格以覆盖连续读数。

    不做半网格增宽的采样最大值通常只是下估，不能称为上界。
    """

    def __init__(
        self, polygon: Sequence[Point], error_deg: float = 1.0,
        angle_step_deg: float = 0.5, angle_origin_deg: float = 0.0,
    ) -> None:
        if not polygon:
            raise ValueError("首次外包区域为空，无法进行第二点选择")
        if not isfinite(angle_step_deg) or not 0.0 < angle_step_deg <= 30.0:
            raise ValueError("角度扫描步长须位于 (0, 30] 度")
        self.polygon = list(polygon)
        self.count = ceil(360.0 / angle_step_deg)
        self.step = 360.0 / self.count
        self.widened_error = error_deg + self.step / 2.0
        if not 0.0 < self.widened_error < 90.0:
            raise ValueError("增宽后的误差半角须位于 (0, 90) 度")
        self.normals: list[tuple[float, Point, Point]] = []
        for k in range(self.count):
            angle = (angle_origin_deg + k * self.step) % 360.0
            lower = unit(angle - self.widened_error)
            upper = unit(angle + self.widened_error)
            self.normals.append((angle, (lower[1], -lower[0]), (-upper[1], upper[0])))

    def evaluate(self, point: Point) -> BoundResult:
        maximum = -1.0
        worst_angle = 0.0
        worst_polygon: list[Point] = []
        for angle, n1, n2 in self.normals:
            polygon = clip_polygon(self.polygon, HalfPlane(*n1, dot(n1, point)))
            if not polygon:
                continue
            polygon = clip_polygon(polygon, HalfPlane(*n2, dot(n2, point)))
            if not polygon:
                continue
            diameter, _ = diameter_bruteforce(polygon)
            if diameter > maximum:
                maximum, worst_angle, worst_polygon = diameter, angle, polygon
        return BoundResult(max(0.0, maximum), worst_angle, self.step, self.widened_error, worst_polygon)


@dataclass(frozen=True)
class SearchConfig:
    radius_min: float = 1000.0
    radius_max: float = 1500.0
    target_radius: float = 1800.0
    circle_sides: int = 360
    # 每层：移动距离步长（米）、移动方位步长（度）、评分角度步长（度）。
    stages: tuple[tuple[float, float, float], ...] = (
        (100.0, 5.0, 1.0),
        (20.0, 1.0, 0.5),
        (5.0, 0.25, 0.25),
    )
    final_angle_step_deg: float = 0.1


def _grid(start: float, end: float, step: float) -> list[float]:
    return [start + i * step for i in range(max(0, int((end - start) / step + 1e-8) + 1))]


def select_second_point(
    reading: Bearing,
    config: SearchConfig | None = None,
    progress: Callable[[str], None] | None = None,
) -> dict:
    """有限多层候选搜索；保证候选可接收，不宣称连续全局最优。"""
    config = config or SearchConfig()
    if not (0 < config.radius_min <= config.radius_max and reading.error_deg < 45.0):
        raise ValueError("选点要求 0 < R_min <= R_max，且本方法的误差半角小于 45 度")
    if not config.stages or any(not all(isfinite(x) and x > 0 for x in stage) for stage in config.stages):
        raise ValueError("至少需要一层正步长的搜索网格")
    polygon = first_region_outer(reading, config.radius_max, config.target_radius, config.circle_sides)
    if not polygon:
        raise ValueError("首次观测与目标区域/接收距离上界不相容")
    best_r, best_beta = 0.0, 0.0
    history: list[dict] = []
    last_r_step, last_beta_step = 0.0, 0.0
    evaluations = 0
    all_candidates: dict[tuple[float, float], tuple[float, float, float, float]] = {}

    for level, (r_step, beta_step, scan_step) in enumerate(config.stages):
        if level == 0:
            radii = _grid(r_step, config.radius_min, r_step) + [config.radius_min]
            betas = _grid(-90.0, 90.0, beta_step)
        else:
            radii = _grid(max(r_step, best_r - last_r_step), min(config.radius_min, best_r + last_r_step), r_step)
            radii += [best_r, config.radius_min] if best_r + last_r_step >= config.radius_min else [best_r]
            # 同时细化镜像位置，避免对称点的浮点平局影响后续搜索。
            betas = []
            for center in (best_beta, -best_beta):
                betas += _grid(center - last_beta_step, center + last_beta_step, beta_step) + [center]
        evaluator = DiameterBoundEvaluator(polygon, reading.error_deg, scan_step, reading.bearing_deg)
        candidates: list[tuple[float, float, float, float, float]] = []
        seen: set[tuple[float, float]] = set()
        for r in radii:
            for beta in betas:
                a, b = r * cos(radians(beta)), r * sin(radians(beta))
                key = round(a, 8), round(b, 8)
                if key in seen or not candidate_allowed(a, b, reading.error_deg, config.radius_min):
                    continue
                seen.add(key)
                all_candidates[key] = (r, beta, a, b)
                result = evaluator.evaluate(to_world(reading, a, b))
                candidates.append((result.diameter_upper_m, r, beta, a, b))
        if not candidates:
            raise ValueError("该搜索网格没有合法候选点；请减小网格步长")
        # 仅将最后几位浮点差异视为平局；平局优先短移动，再优先正侧。
        chosen = min(candidates, key=lambda c: (round(c[0], 7), c[1], abs(c[2]), -c[2]))
        score, best_r, best_beta, best_a, best_b = chosen
        evaluations += len(candidates)
        history.append({
            "level": level + 1, "candidate_count": len(candidates),
            "radial_step_m": r_step, "azimuth_step_deg": beta_step,
            "score_angle_step_deg": evaluator.step,
            "chosen_local_m": [best_a, best_b], "diameter_upper_m": score,
        })
        if progress is not None:
            progress(f"第 {level + 1} 层：{len(candidates)} 个候选，直径上界 {score:.6f} m")
        last_r_step, last_beta_step = r_step, beta_step

    final_evaluator = DiameterBoundEvaluator(
        polygon, reading.error_deg, config.final_angle_step_deg, reading.bearing_deg,
    )
    final_choices = []
    for r, beta, a, b in all_candidates.values():
        bound = final_evaluator.evaluate(to_world(reading, a, b))
        final_choices.append((bound.diameter_upper_m, r, beta, a, b, bound))
    chosen = min(final_choices, key=lambda c: (round(c[0], 7), c[1], abs(c[2]), -c[2]))
    _, best_r, best_beta, best_a, best_b, final_bound = chosen
    evaluations += len(final_choices)
    selected = to_world(reading, best_a, best_b)
    if progress is not None:
        progress(f"统一精度复核：{len(final_choices)} 个候选，直径上界 {final_bound.diameter_upper_m:.6f} m")
    return {
        "method": "signal_safe_multilevel_minimax_upper_bound",
        "scope": "offline_mathematical_calculation",
        "first_reading": asdict(reading),
        "selected_position_m": selected,
        "selected_local_m": [best_a, best_b],
        "movement_distance_m": hypot(best_a, best_b),
        "movement_time_s": hypot(best_a, best_b) / 5.0,
        "second_measure_total_time_s": hypot(best_a, best_b) / 5.0 + 5.0,
        "same_channel_assumed": True,
        "signal_guaranteed_by_candidate_region": True,
        "distance_from_first_wedge_m": bearing_clearance(best_a, best_b, reading.error_deg),
        "worst_diameter_upper_m": final_bound.diameter_upper_m,
        "bound_angle_step_deg": final_bound.angle_step_deg,
        "bound_widened_error_deg": final_bound.widened_error_deg,
        "bound_worst_cell_center_deg": final_bound.cell_center_deg,
        "bound_worst_outer_polygon": final_bound.worst_outer_polygon,
        "first_outer_polygon": polygon,
        "circle_sides": config.circle_sides,
        "search_evaluations": evaluations,
        "final_candidate_count": len(final_choices),
        "finite_candidate_set_minimizer": True,
        "search_history": history,
        "continuous_global_optimum_proven": False,
        "numerical_note": "数学外包上界；计算采用双精度容差，不是区间算术认证",
    }

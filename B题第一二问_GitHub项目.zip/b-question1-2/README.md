# 2026 国赛 B 题第一问与第二问

本项目包含两问的完整推导、可运行 Python 代码、自动检查、示例输入、自建数值验证和静态示意图。核心代码仅使用 Python 标准库，没有网络或模拟器调用。

**完整解答：[docs/solution.md](docs/solution.md)**  
**数值结果：[docs/numerical_results.md](docs/numerical_results.md)**

## 已解决的问题

| 问题 | 方法与结果 |
| --- | --- |
| 第一问 | 以闭半平面交构造示向扇形交会区域，区分空集、无界、点、线段和多边形；通过凸包顶点对及旋转卡壳求直径 |
| 第一问覆盖圆 | 同直径圆不一定覆盖区域；提供符合 ±1° 测向条件的等边三角形反例，以及覆盖的充要判据和最小包围圆计算 |
| 第二问候选区域 | 利用首次接收成功的条件，推导三个半径 1000 米圆盘交集，保证移动后仍能接收全向源信号 |
| 第二问选点 | 筛选保证返回正常示向度的候选点；按所有可能第二次读数的保守直径上界进行多层搜索，并统一精度复核 |

三角形反例的直径为 **40 米**，最小包围圆半径为 **23.094 米**。因此，“定位区域直径不超过 40 米”不能单独保证能找到一个清除点距全部可能源位置不超过 20 米。

在原点测得正东方向的自建示例中，程序选择约 **(848.048, 529.919) 米**，第二次定位直径上界约 **113.038 米**。这是指定输入下、已访问有限候选集合中保守评分的数值最优结果，未证明连续全局最优。

![第一问反例](docs/figures/q1_counterexample.svg)

## 快速运行

需要 Python 3.10 或以上。解压后进入项目根目录，无需安装本项目或额外依赖即可运行：

~~~bash
python -B -X utf8 -m b12 q1 examples/q1_triangle.json
python -B -X utf8 -m b12 q1 examples/q1_two_bearings.json
python -B -X utf8 -m b12 q2 examples/q2_origin.json --output results/local/q2.json
~~~

第二问快速检查可只进行粗网格搜索：

~~~bash
python -B -X utf8 -m b12 q2 examples/q2_origin.json --quick --angle-step 1
~~~

运行自动检查、重现全部示例和验证网格：

~~~bash
python -B -X utf8 -m unittest discover -s tests -v
python -B -X utf8 scripts/run_experiments.py
~~~

完整搜索会将所有访问过的候选点以统一精度再次评分，计算量比快速模式大。程序输出搜索进度到标准错误，JSON 结果单独写入标准输出或指定文件。

## 输入格式

第一问输入为同一干扰源的多个观测，长度单位为米，角度单位为度：

~~~json
{
  "readings": [
    {"x": 0, "y": 0, "bearing_deg": 33.69, "error_deg": 1.0},
    {"x": 800, "y": 0, "bearing_deg": 116.57, "error_deg": 1.0}
  ]
}
~~~

第二问仅需要第一次观测，不能给选点器传入未知真实源位置：

~~~json
{
  "first_reading": {
    "x": 0,
    "y": 0,
    "bearing_deg": 0,
    "error_deg": 1.0
  }
}
~~~

角度从正东逆时针计，跨越 0° 的情况已处理。省略误差半角时默认 1°。首次结果若为 near，应采用近距离定位与清除，不需要把它构造成伪造的示向度输入。

## 输出的含义

第一问输出区域类型、顶点、直径端点、同直径圆是否覆盖，以及最小包围圆。无界时使用 <code>diameter_infinite=true</code> 且 <code>diameter_m=null</code>；空集时直径未定义。该命令计算纯示向扇形交，不会悄悄用大矩形截断无界区域。

第二问输出推荐点、移动距离和耗时、保守直径上界、网格参数、各层搜索记录与有限候选数量。默认最终角度网格为 0.1°，评分半角增宽为 1.05°以覆盖连续读数；获得实际第二次观测后仍按题面 1° 进行定位。

保证信号可接收的结论来自集合证明，不能用有限验证网格的通过率代替。数值上界使用双精度浮点容差，未实现区间算术认证；连续候选区域的全局最优也未获证明。

## 项目结构

~~~text
b12/
  geometry.py                 半平面交、凸包、直径与最小包围圆
  selection.py                安全候选区域、连续读数上界和第二点搜索
  __main__.py                 命令行入口
docs/
  solution.md                 完整数学解答与证明
  numerical_results.md        自动生成的数值结果表
  figures/                    已生成的 SVG 和 PNG
examples/                     四组可直接运行的 JSON 输入
tests/                        标准库 unittest 检查
scripts/
  run_experiments.py           重现自建数值验证
  render_figures.py            可选绘图脚本
  verify_reference.py          可选独立求解器核验
  build_bundle.py              生成并检查 GitHub 项目压缩包
results/                      随仓库保存的示例结果和验证记录
.gitignore                    排除原始材料、模拟器、缓存和临时输出
pyproject.toml                包元数据，核心运行依赖为空
~~~

## 可选复核与绘图

已提供静态图片，查看解答不需要绘图依赖。若现有 Python 环境已安装 matplotlib，可重画图；若已安装 SciPy，可做独立线性规划交叉核验：

~~~bash
python -B -X utf8 scripts/render_figures.py
python -B -X utf8 scripts/verify_reference.py
~~~

绘图脚本将字体缓存和临时目录设置在项目内。中文图片重绘需要可用的中文字体；已交付 SVG 将字体转为路径，查看时不依赖本机字体。

标准库检查通过 21 项测试，并包含数百组内部随机样本。独立参考核验对 500 组随机半平面系统进行分类及坐标方向支持值比较，保存结果中不匹配数均为 0。自建源位置网格有 1281 个位置，每个可正常测向的位置再枚举 5 个第二次误差情景。

## GitHub 文件与打包

解压交付的 ZIP 后，将其中项目目录的内容放入 GitHub 仓库即可。压缩包含校验清单，代码和文档相对链接均可随仓库移动。

重新生成压缩包并在项目内解压检查：

~~~bash
python -B -X utf8 scripts/build_bundle.py --verify
~~~

打包器只收集解答、代码、示例、静态图和必要结果；原始题目、官方模拟器、本机规则、临时缓存及历史打包文件不会进入压缩包。Git 忽略规则同时保留这些排除设置，源文件不会被删除。

本项目所有已保存数值都是自建离线结果，**没有进行官方演练或正式测试**。正式测试禁止执行。

"""重现论文示例及自建验证网格；不启动模拟器，不使用 HTTP。

在项目根目录运行：python -B scripts/run_experiments.py
"""

from __future__ import annotations

import json
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from b12.__main__ import analyze_question1
from b12.geometry import Bearing, clip_with_bearing, diameter_bruteforce, distance
from b12.selection import DiameterBoundEvaluator, SearchConfig, first_region_outer, select_second_point, signal_safe


def save(name: str, data: dict) -> None:
    (ROOT / "results").mkdir(exist_ok=True)
    (ROOT / "results" / name).write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def main() -> None:
    for name in ("q1_triangle", "q1_two_bearings"):
        data = json.loads((ROOT / "examples" / f"{name}.json").read_text(encoding="utf-8"))
        save(f"{name}.json", analyze_question1([Bearing(**r) for r in data["readings"]]))
    selected = {}
    for name in ("q2_origin", "q2_boundary"):
        data = json.loads((ROOT / "examples" / f"{name}.json").read_text(encoding="utf-8"))
        result = select_second_point(Bearing(**data["first_reading"]), progress=lambda line: print(f"{name}: {line}", flush=True))
        selected[name] = result
        save(f"{name}.json", result)

    reading = Bearing(0, 0, 0)
    polygon = first_region_outer(reading)
    points = [
        ("forward_750", "沿示向方向前进 750 米", (750.0, 0.0)),
        ("perpendicular_750", "横向移动 750 米", (0.0, 750.0)),
        ("diagonal_45deg", "移动 1000 米、偏转 45 度", (math.sqrt(500000), math.sqrt(500000))),
        ("simple_800_600", "简明安全点 (800,600)", (800.0, 600.0)),
        ("selected", "本文多层搜索点", tuple(selected["q2_origin"]["selected_local_m"])),
    ]
    evaluator = DiameterBoundEvaluator(polygon, 1.0, 0.1)
    rows = []
    # 网格不是关于真实环境的概率分布，只检查离散组合。
    ranges = [6.0 + (1500.0 - 6.0) * i / 60 for i in range(61)]
    angles = [-1.0 + 2.0 * i / 20 for i in range(21)]
    second_errors = [-1.0, -0.5, 0.0, 0.5, 1.0]
    for key, label, point in points:
        safety = signal_safe(*point)
        upper = evaluator.evaluate(point).diameter_upper_m
        signal_count, near_count, max_sample_diameter, direction_count = 0, 0, 0.0, 0
        sample_upper_violations = 0
        for r in ranges:
            for phi in angles:
                source = r * math.cos(math.radians(phi)), r * math.sin(math.radians(phi))
                minimum_compatible_radius = max(1000.0, r)
                d = distance(point, source)
                if d > minimum_compatible_radius + 1e-8:
                    continue
                signal_count += 1
                if d <= 5.0:
                    near_count += 1
                    continue
                true_direction = math.degrees(math.atan2(source[1] - point[1], source[0] - point[0]))
                for error in second_errors:
                    posterior = clip_with_bearing(polygon, Bearing(*point, true_direction + error))
                    if not posterior:
                        raise AssertionError("与真值相容的观测不应产生空集")
                    diameter, _ = diameter_bruteforce(posterior)
                    max_sample_diameter = max(max_sample_diameter, diameter)
                    sample_upper_violations += diameter > upper + 1e-6
                    direction_count += 1
        rows.append({
            "key": key, "label": label, "local_position_m": point,
            "movement_m": math.hypot(*point), "signal_guaranteed": safety,
            "source_grid_count": len(ranges) * len(angles),
            "source_grid_signal_count": signal_count, "source_grid_near_count": near_count,
            "direction_error_combinations": direction_count,
            "sample_signal_fraction": signal_count / (len(ranges) * len(angles)),
            "direction_only_sample_max_diameter_m": max_sample_diameter,
            "direction_only_diameter_upper_m": upper,
            "sample_upper_violations": sample_upper_violations,
            "bound_scope": "条件为已返回示向度；无信号情况不适用，故不能单用此值比较不安全策略",
        })
        print(f"{key}: signal={signal_count}/{len(ranges) * len(angles)}, upper={upper:.6f} m", flush=True)
    summary = {
        "provenance": "自建确定性数学网格；不是官方演练或正式测试",
        "source_ranges_m": {"min": 6.0, "max": 1500.0, "count": 61},
        "first_true_angle_offset_deg": {"min": -1.0, "max": 1.0, "count": 21},
        "second_error_deg": second_errors,
        "radio_radius": "每个源采用与首次观测相容的最小半径 max(1000, r1)",
        "rows": rows,
    }
    save("validation_grid.json", summary)
    selected_row = rows[-1]
    if selected_row["sample_signal_fraction"] != 1.0 or selected_row["sample_upper_violations"]:
        raise AssertionError("选点验证失败")

    table = [
        "# 自建数值验证", "",
        "以下均为离线数学计算，不是官方演练或正式测试。每个策略使用相同的 1281 个源位置组合；有示向度时，再枚举 5 个第二次误差。", "",
        "| 策略 | 第二点局部坐标（米） | 移动距离（米） | 网格可接收率 | 示向度分支的直径上界（米） |",
        "| --- | --- | ---: | ---: | ---: |",
    ]
    for row in rows:
        a, b = row["local_position_m"]
        table.append(f"| {row['label']} | ({a:.3f}, {b:.3f}) | {row['movement_m']:.3f} | {row['sample_signal_fraction']:.2%} | {row['direction_only_diameter_upper_m']:.3f} |")
    table += ["", "横向策略不保证第二次可接收，其直径上界仅描述已得到示向度的分支；不能忽略丢失信号的情况而将它称为可行最优策略。", "",
              "理论可接收保证来自三个圆盘交集的证明，不来自网格中的 100% 通过率。全角度上界采用 0.1° 网格并将第二次误差半角增宽到 1.05°。", "",
              "| 场景 | 选择点的世界坐标（米） | 第二点移动耗时（秒） | 最坏直径上界（米） |", "| --- | --- | ---: | ---: |"]
    for name, result in selected.items():
        x, y = result["selected_position_m"]
        table.append(f"| {name} | ({x:.3f}, {y:.3f}) | {result['movement_time_s']:.3f} | {result['worst_diameter_upper_m']:.3f} |")
    table += ["", "接近目标圆域边界的场景使用了更紧的先验可行区域。两组数值是指定输入下的策略结果，不是普适固定检测点。", "",
              "原始数值见 `results/*.json`。候选搜索不宣称连续全局最优；直径上界是外包几何的浮点计算结果。", ""]
    (ROOT / "docs").mkdir(exist_ok=True)
    (ROOT / "docs/numerical_results.md").write_text("\n".join(table), encoding="utf-8")


if __name__ == "__main__":
    main()

"""命令行入口。所有操作均为离线计算。"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import asdict, replace
from pathlib import Path

from .geometry import Bearing, Circle, diameter_calipers, distance, localize, minimum_enclosing_circle, polygon_area
from .selection import SearchConfig, select_second_point


def analyze_question1(readings: list[Bearing]) -> dict:
    region = localize(readings)
    result = {
        "status": region.status,
        "vertices_m": region.vertices,
        "feasible_witness_m": region.witness,
        "recession_direction": region.recession,
        "diameter_m": None,
        "diameter_infinite": region.status == "unbounded",
        "scope": "bearing_wedge_intersection_only",
    }
    if region.status in ("empty", "unbounded"):
        return result
    diameter, endpoints = diameter_calipers(region.vertices)
    midpoint = tuple((a + b) / 2 for a, b in zip(*endpoints))
    circle = Circle(midpoint, diameter / 2.0)
    enclosing = minimum_enclosing_circle(region.vertices)
    result.update({
        "diameter_m": diameter, "diameter_endpoints_m": endpoints,
        "area_m2": polygon_area(region.vertices),
        "diameter_circle_center_m": midpoint,
        "diameter_circle_radius_m": diameter / 2.0,
        "diameter_circle_covers": all(circle.contains(p) for p in region.vertices),
        "minimum_enclosing_circle": asdict(enclosing),
        "guaranteed_clear_from_enclosing_center": enclosing.radius <= 20.0 + 1e-8,
        "max_distance_from_diameter_midpoint_m": max(distance(midpoint, p) for p in region.vertices),
    })
    return result


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="B 题第一、二问离线几何工具；没有模拟器或 HTTP 接口")
    subparsers = parser.add_subparsers(dest="question", required=True)
    for question in ("q1", "q2"):
        sub = subparsers.add_parser(question)
        sub.add_argument("input", type=Path, help="UTF-8 JSON 输入文件")
        sub.add_argument("--output", type=Path, help="输出 JSON；省略则写到标准输出")
        if question == "q2":
            sub.add_argument("--quick", action="store_true", help="仅做第一层候选搜索，适合冒烟运行")
            sub.add_argument("--angle-step", type=float, default=0.1, help="最终上界角度步长，默认 0.1 度")
    args = parser.parse_args(argv)
    try:
        data = json.loads(args.input.read_text(encoding="utf-8-sig"))
        if args.question == "q1":
            result = analyze_question1([Bearing(**item) for item in data["readings"]])
        else:
            config = replace(SearchConfig(), final_angle_step_deg=args.angle_step)
            if args.quick:
                config = replace(config, stages=config.stages[:1])
            result = select_second_point(Bearing(**data["first_reading"]), config, lambda message: print(message, file=sys.stderr))
        output = json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
        if args.output is None:
            print(output, end="")
        else:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(output, encoding="utf-8")
        return 0
    except (OSError, ValueError, KeyError, TypeError, ArithmeticError) as error:
        print(f"错误：{error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

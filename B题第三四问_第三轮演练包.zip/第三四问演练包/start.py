"""Interactive launcher; all robot actions remain in the confirmed serial client."""
import os
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent


def main():
    if sys.version_info < (3, 10):
        print("需要 Python 3.10 或更新版本，无需安装第三方依赖。")
        return 2
    print("B题第三、四问 · 第三轮改进版")
    print("本地多轮成绩：第三问244.94、第四问450.40秒/源，尚未达到200/400目标。")
    print("1  第三问本地自检\n2  第四问本地自检\n3  第三问演练\n4  第四问演练\n0  退出")
    selection = input("请选择 0—4：").strip()
    if selection == "0":
        return 0
    if selection not in ("1", "2", "3", "4"):
        print("选择无效，未启动任何测试。")
        return 2
    problem = 3 if selection in ("1", "3") else 4
    command = [sys.executable, "-B", "-X", "utf8", str(ROOT / f"problem{problem}/run.py")]
    if selection in ("3", "4"):
        print(f"请先在模拟器开启一局问题{problem}演练，等待接口就绪。不要选择正式测试。")
        robot_id = input("输入模拟器当前登录的真实参赛队号（不是密码）：").strip()
        if not robot_id:
            print("没有填写队号，已取消。")
            return 2
        port_text = input("接口端口（直接回车使用2026）：").strip() or "2026"
        if not port_text.isascii() or not port_text.isdigit() or not 1 <= int(port_text) <= 65535:
            print("端口无效，已取消。")
            return 2
        command += ["--backend", "rehearsal", "--robot-id", robot_id, "--port", port_text]
    env = os.environ.copy()
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    # A list with shell=False prevents the entered team number becoming shell code.
    return subprocess.run(command, cwd=ROOT, env=env, shell=False).returncode


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (KeyboardInterrupt, EOFError):
        print("已取消。")
        raise SystemExit(2)

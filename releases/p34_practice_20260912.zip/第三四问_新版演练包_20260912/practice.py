"""One fixed v5 candidate, one local self-check or operator-confirmed rehearsal."""
from __future__ import annotations

import argparse
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import importlib
import json
import os
from pathlib import Path
import sys
import time
import unicodedata
import uuid

ROOT = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
VERSIONS = {3: 'problem3_v5_continuous', 4: 'problem4_v5_visibility_discovery'}


def bounded(path):
    result = Path(path).resolve()
    if not result.is_relative_to(ROOT):
        raise ValueError('文件或缓存路径超出当前演练包，已停止。')
    return result


def initialize():
    if sys.version_info < (3, 10):
        raise RuntimeError('需要 Python 3.10 以上；第四问建议使用菜单选择的 Python 3.12 环境。')
    cache = bounded(ROOT / 'cache')
    cache.mkdir(exist_ok=True)
    os.environ.update(PYTHONDONTWRITEBYTECODE='1', TEMP=str(cache), TMP=str(cache),
                      MPLCONFIGDIR=str(cache / 'matplotlib'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_sources():
    manifest_path = ROOT / 'source_manifest.json'
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    for name, expected in manifest['copied_files_sha256'].items():
        path = (ROOT / name).resolve()
        if not path.is_relative_to(ROOT) or not path.is_file() or digest(path) != expected:
            raise RuntimeError(f'版本文件缺失或已改变：{name}。请重新解压完整演练包。')
    return digest(manifest_path)


def build_policy(problem):
    if problem == 4:
        try:
            import numpy
        except ImportError as exc:
            raise RuntimeError('第四问需要 NumPy。请双击本包启动菜单，优先使用已有的已验证环境。') from exc
        print(f'NumPy：{numpy.__version__}（本轮评测版本 2.3.5）', flush=True)
    module = importlib.import_module(f'experiments_v5.p{problem}_candidate')
    policy = module.SearchPolicy(problem=problem, strategy='adaptive', config=None)
    if policy.algorithm_version != VERSIONS[problem]:
        raise RuntimeError('候选版本不一致，启动已停止。')
    return policy


def validate_team(value):
    if (not isinstance(value, str) or value != value.strip()
            or not 1 <= len(value.encode('utf-8')) <= 64
            or value in {'TEAM_ID', '你的队号', '你的真实参赛队号'}
            or any(unicodedata.category(c) in {'Cc', 'Cf', 'Cs'} for c in value)):
        raise ValueError('请填写界面当前登录的真实队号，保留前导零，不填密码或占位文字。')


def confirm_rehearsal(problem):
    label = f'问题{problem}演练测试'
    print(f'请先核对模拟器页面是“{label}”，且接口已经就绪。')
    print('接口无法自动识别演练或正式模式；页面不是演练时，请按 Ctrl+C 退出。')
    answer = input(f'确认后完整输入“{label}”：').strip()
    if answer != label:
        raise ValueError('未确认对应演练，未发送任何接口请求。')
    return {'confirmed_label': label, 'confirmed_at_utc': datetime.now(timezone.utc).isoformat(),
            'basis': 'operator checked the simulator UI; HTTP API does not expose test mode'}


@contextmanager
def single_program():
    """OS releases this package's lock even if the process is interrupted."""
    path = bounded(ROOT / 'cache' / 'program.lock')
    with path.open('a+b') as handle:
        handle.seek(0, 2)
        if handle.tell() == 0:
            handle.write(b'0')
            handle.flush()
        handle.seek(0)
        try:
            if os.name == 'nt':
                import msvcrt
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as exc:
            raise RuntimeError('本包已有程序运行，请等上一局结束后再启动。') from exc
        try:
            yield
        finally:
            handle.seek(0)
            if os.name == 'nt':
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def public_client(client, violations):
    """The same six-member contract used in the frozen local evaluation."""
    class PublicClient:
        __slots__ = ()
        def __getattribute__(self, name):
            if name not in {'position', 'current_channel', 'virtual_time_s', 'check_budget', 'measure', 'clear'}:
                violations.append(name)
                raise AttributeError('策略访问了非公开接口成员')
            if violations:
                raise RuntimeError('本次接口使用检查未通过')
            return object.__getattribute__(self, name)
        @property
        def position(self): return client.position
        @property
        def current_channel(self): return client.current_channel
        @property
        def virtual_time_s(self): return client.virtual_time_s
        def check_budget(self): return client.check_budget()
        def measure(self, point, channel): return client.measure(point, channel)
        def clear(self, point, channel): return client.clear(point, channel)
    return PublicClient()


def offline_client(problem):
    # This exact old training example was already used before the shared 7000 set.
    from problem3 import scenarios
    from problem3.simulator import LocalSimulator
    scenarios.SPLITS['train_v5'] = (257000003, 384)
    case = scenarios.generate_case(problem, 0, 'train_v5')
    return LocalSimulator(case, record=True)


def execute(problem, backend, policy, client, output, confirmation, source_hash):
    from problem3.client import BudgetExceeded
    started = time.perf_counter()
    result, error = {}, None
    entered = exited = False
    violations = []
    try:
        if client.enter().get('accepted') is not True:
            raise RuntimeError('进入被拒绝。请核对当前演练、队号及端口；不要在同一局反复重启。')
        entered = True
        print('已进入。程序正在自动测量、移动和清除；一次只运行当前这一局。', flush=True)
        policy_result = policy.run(public_client(client, violations))
        if violations or not isinstance(policy_result, dict):
            raise RuntimeError('候选返回或接口使用无效')
        json.dumps(policy_result, allow_nan=False)
        result = policy_result
        exited = client.exit().get('accepted') is True
        if not exited:
            raise RuntimeError('退出未获确认，请保存日志并查看模拟器状态。')
    except BudgetExceeded as exc:
        error = f'{type(exc).__name__}: {exc}'
        if backend == 'rehearsal' and client.can_exit:
            try:
                exited = client.exit().get('accepted') is True
            except Exception as exit_error:
                error += f'; exit: {type(exit_error).__name__}: {exit_error}'
    except (Exception, KeyboardInterrupt) as exc:
        # A lost response can mean the previous action executed: do not send
        # a different action or retry with a freshly created request ID here.
        error = f'{type(exc).__name__}: {exc}'
    pending = client.pending_request if backend == 'rehearsal' else None
    final = bool(exited and pending is None)
    count = len(policy.cleared)
    observed_average = client.virtual_time_s / count if count else None
    summary = {
        'package_version': 'v5_practice_20260912', 'problem': problem,
        'algorithm_version': VERSIONS[problem], 'backend': backend,
        'data_origin': 'local_selfcheck_not_official' if backend == 'offline' else 'operator_confirmed_official_rehearsal',
        'formal_test_requested': False, 'platform_mode_verified_by_program': False,
        'operator_confirmation': confirmation,
        'source_manifest_sha256': source_hash, 'python_version': sys.version,
        'python_executable': sys.executable, 'entered': entered, 'exit_accepted': exited,
        'statistics_final': final, 'completion_certified': bool(result.get('completion_certified')),
        'cleared_count': count, 'source_count': None, 'virtual_time_s': client.virtual_time_s,
        'average_clear_time_s': observed_average if final else None,
        'observed_average_clear_time_s': observed_average,
        'pending_request_id': pending.get('request_id') if pending else None,
        'policy': result, 'error': error, 'local_wall_time_s': time.perf_counter() - started,
        'needs_platform_end_screen_check': backend == 'rehearsal',
        'note': '平台源总数及最终成绩以演练结束页为准；未确认退出时不能把本地观测当最终成绩。',
    }
    if backend == 'offline':
        summary['offline_statistics'] = client.statistics()
        summary['source_count'] = summary['offline_statistics']['source_count']
        summary['all_sources_cleared'] = count == summary['source_count']
        with (output / 'actions.jsonl').open('x', encoding='utf-8') as handle:
            for event in client.events:
                handle.write(json.dumps(event, ensure_ascii=False) + '\n')
    else:
        summary['all_sources_cleared'] = None
    okay = bool(error is None and final and summary['completion_certified']
                and (backend == 'rehearsal' or summary['all_sources_cleared']))
    summary['program_completed'] = okay
    (output / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print('来源：' + ('本地自检' if backend == 'offline' else '用户确认的官方演练'))
    print(f'已清除 {count} 个；已确认虚拟时间 {client.virtual_time_s:.3f} 秒。')
    if final and observed_average is not None:
        print(f'平均时间：{observed_average:.3f} 秒/源。')
    else:
        print('没有可确认的最终平均成绩；请保存日志，不要在同一局直接重启。')
    if backend == 'rehearsal':
        print('请到演练结束页核对源总数 N 与清除数 C，C=N 才算全部清除。')
        print('下一局需在模拟器重新开启演练，再重新启动本菜单。')
    print(f'结果：{output / "summary.json"}')
    if error:
        print(error, file=sys.stderr)
    return 0 if okay else 2


def main(problem=None, argv=None):
    parser = argparse.ArgumentParser(description='冻结 v5 候选：默认本地自检；仅支持人工确认的演练。')
    if problem is None:
        parser.add_argument('--problem', type=int, choices=(3, 4), required=True)
    parser.add_argument('--backend', choices=('offline', 'rehearsal'), default='offline')
    parser.add_argument('--robot-id')
    parser.add_argument('--port', type=int, default=2026)
    parser.add_argument('--version', action='store_true')
    args = parser.parse_args(argv)
    problem = problem or args.problem
    if not 1 <= args.port <= 65535:
        parser.error('端口必须为 1—65535。')
    if args.backend == 'rehearsal':
        validate_team(args.robot_id)
    elif args.robot_id:
        parser.error('本地自检不需要队号。')
    initialize()
    source_hash = verify_sources()
    print(f'新版演练包 | 问题{problem} | {VERSIONS[problem]}', flush=True)
    print(f'Python：{sys.executable}', flush=True)
    policy = build_policy(problem)
    if args.version:
        return 0
    with single_program():
        confirmation = confirm_rehearsal(problem) if args.backend == 'rehearsal' else None
        stamp = datetime.now().strftime('%Y%m%d_%H%M%S') + '_' + uuid.uuid4().hex[:8]
        output = bounded(ROOT / 'outputs' / f'problem{problem}' / f'{args.backend}_{stamp}')
        output.mkdir(parents=True, exist_ok=False)
        if args.backend == 'offline':
            def no_network(event, values):
                if event in {'socket.connect', 'socket.bind', 'socket.getaddrinfo'}:
                    raise RuntimeError('本地自检禁止网络连接')
            sys.addaudithook(no_network)
            client = offline_client(problem)
        else:
            from problem3.client import HttpClient
            client = HttpClient(f'http://127.0.0.1:{args.port}', args.robot_id, output / 'actions.jsonl')
        return execute(problem, args.backend, policy, client, output, confirmation, source_hash)


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (ValueError, RuntimeError, OSError, KeyboardInterrupt, EOFError) as exc:
        print(f'启动已停止：{exc}', file=sys.stderr)
        raise SystemExit(2)

# PowerShell 操作

推荐直接双击 `启动菜单.cmd`；不需要管理员权限。以下命令只在本包目录执行。

先打开 PowerShell，复制：

```powershell
Set-Location -LiteralPath "C:\Users\lenovo\Desktop\国赛2026\第三四问_新版演练包_20260912"
.\启动菜单.cmd
```

若要直接输入 Python 命令，这台电脑使用评测时已有的环境：

```powershell
$pyRun = Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
& $pyRun -B -X utf8 problem3/run.py
& $pyRun -B -X utf8 problem4/run.py
```

上面两条只是本地自检，不连接模拟器。队友电脑若没有这个环境，可将 `& $pyRun` 换成其已配置的 `python`；第四问需要 NumPy，推荐 Python 3.12、NumPy 2.3.5。

**先在模拟器开启问题3演练、等待接口就绪**，再运行下面一条。将占位文字换成当前登录的真实队号：

```powershell
& $pyRun -B -X utf8 problem3/run.py --backend rehearsal --robot-id "你的真实参赛队号" --port 2026
```

核对页面确实为第三问演练后，完整输入 `问题3演练测试`。不要选择正式测试。

另开问题4演练后，才执行：

```powershell
& $pyRun -B -X utf8 problem4/run.py --backend rehearsal --robot-id "你的真实参赛队号" --port 2026
```

对应确认文字为 `问题4演练测试`。两条演练命令不要同时运行。端口如果改过，命令中也要改成一样的值。

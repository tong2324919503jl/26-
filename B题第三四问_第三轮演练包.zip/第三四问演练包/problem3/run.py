"""Run the frozen phase-3 candidate locally or in operator-confirmed rehearsal."""
from __future__ import annotations

import sys
sys.dont_write_bytecode = True
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import argparse
from datetime import datetime
import json
import time
import uuid
from problem3.protocol import Client, HttpExchange, confirm_rehearsal, output_path, validate_id
from problem3.simulation import LocalWorld


def candidate(api, problem, config):
    if problem == 3:
        from problem3.phase3_intercept import factory
        return factory(api, 3, parameters=config["parameters"], step=450, radius=1600)
    from problem4.phase3_candidate import factory
    return factory(api, 4, parameters=config["parameters"])


def main(problem=3):
    folder = ROOT / f"problem{problem}"
    parser = argparse.ArgumentParser(description=f"第三轮改进版：问题{problem}；默认只跑本地案例")
    parser.add_argument("--backend", choices=("offline", "rehearsal"), default="offline")
    parser.add_argument("--example", default=str(folder / "examples/demo.json"))
    parser.add_argument("--robot-id", help="当前登录的真实参赛队号，保留前导零；不填密码")
    parser.add_argument("--port", type=int, default=2026)
    parser.add_argument("--output", help="本文件包内尚不存在的新日志目录")
    args = parser.parse_args()
    if not 1 <= args.port <= 65535:
        parser.error("端口必须在 1..65535")
    config = json.loads((folder / "config.json").read_text(encoding="utf-8-sig"))
    if config["problem"] != problem:
        parser.error("配置与题号不符")
    suffix = datetime.now().strftime("%Y%m%d_%H%M%S") + "_" + uuid.uuid4().hex[:6]
    output = output_path(args.output or folder / "outputs" / f"{args.backend}_{suffix}")
    if output.exists():
        parser.error("输出目录已存在，请另取名称以保留历史日志")

    world = confirmation = None
    print(f"第三轮改进版 | 问题{problem} | {config['branch']}", flush=True)
    if args.backend == "rehearsal":
        if not args.robot_id or args.robot_id in ("你的真实参赛队号", "你的队号", "TEAM_ID"):
            parser.error("演练需要 --robot-id 当前登录的真实参赛队号")
        validate_id(args.robot_id, 64)
        print(f"队号：{args.robot_id}；本机端口：{args.port}")
        confirmation = confirm_rehearsal(problem)
        exchange = HttpExchange(args.port, confirmation)
        robot_id = args.robot_id
    else:
        case = json.loads(output_path(args.example).read_text(encoding="utf-8-sig"))
        if case["problem"] != problem:
            parser.error("案例与题号不符")
        world = LocalWorld(case)
        exchange, robot_id = world.exchange, "offline-team"

    output.mkdir(parents=True)
    client = Client(exchange, robot_id=robot_id, journal=output / "actions.jsonl")
    result = {
        "version": "phase3_practice_20260911",
        "problem": problem,
        "branch": config["branch"],
        "parameters": config["parameters"],
        "candidate_options": config["candidate_options"],
        "threshold_s": config["threshold_s"],
        "data_origin": "local_simulation_not_official" if world else "official_rehearsal",
        "official_formal_test": False,
    }
    if confirmation:
        result["operator_confirmation"] = confirmation
    error = None
    started = time.perf_counter()
    print("正在运行；详细动作在本次 actions.jsonl 中，结束后打印结果。", flush=True)
    try:
        policy = candidate(client, problem, config)
        result.update(policy.run())
        result["policy_branch"] = result.get("branch")
        result["branch"] = config["branch"]
    except (Exception, KeyboardInterrupt) as exc:
        error = f"{type(exc).__name__}: {exc}"
        result.update(complete_certificate=False, error=error,
                      cleared_channels=sorted(client.cleared),
                      virtual_time_s=client.virtual_time, actions=client.counts)
    result["wall_time_s"] = time.perf_counter() - started
    result["cleared_count"] = len(client.cleared)
    result["average_time_s"] = client.virtual_time / len(client.cleared) if client.cleared else None
    if world:
        metrics = world.final_metrics()
        result["offline_evaluation"] = metrics
        result["clearance_fraction"] = metrics["cleared_count"] / metrics["source_count"]
        result["threshold_pass"] = bool(result.get("complete_certificate")
            and metrics["cleared_count"] == metrics["source_count"]
            and result["average_time_s"] is not None
            and result["average_time_s"] < config["threshold_s"])
        result["case_name"] = case["name"]
    else:
        # The public action API does not disclose N. Verify completeness at the end screen.
        result["clearance_fraction"] = None
        result["threshold_pass"] = None
        result["needs_platform_source_count_verification"] = True
    (output / "summary.json").write_text(json.dumps(result, ensure_ascii=False, indent=2)
                                          + "\n", encoding="utf-8")
    print(f"来源：{'本地自建案例' if world else '官方演练'}")
    print(f"已清除 {len(client.cleared)} 个；虚拟总时间 {client.virtual_time:.3f} 秒。")
    average = result["average_time_s"]
    print(f"平均每源 {average:.3f} 秒。" if average is not None else "未清除任何源，平均时间未定义。")
    print("完成依据：" + str(result.get("stop_reason", error)))
    if world:
        print(f"清除比例：{result['clearance_fraction']:.1%}；本地单例达到速度阈值：{result['threshold_pass']}")
    else:
        print("请核对平台结束页的源总数 N、清除数 C 与虚拟时间 T；C=N 才算全部清除。")
        print("本命令只运行一局，不会自动开启下一局或自动计算多局平均。")
    print(f"结果：{output / 'summary.json'}\n动作日志：{output / 'actions.jsonl'}")
    if error:
        print(error, file=sys.stderr)
    return 0 if result.get("complete_certificate") else 2


if __name__ == "__main__":
    try:
        raise SystemExit(main(3))
    except (ValueError, OSError, KeyboardInterrupt) as exc:
        print(f"启动已停止：{exc}", file=sys.stderr)
        raise SystemExit(2)

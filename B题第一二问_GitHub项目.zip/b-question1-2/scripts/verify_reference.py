"""可选的独立数值交叉核验，需 SciPy；核心程序和 unittest 不需要它。"""

from __future__ import annotations

import json
import random
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from scipy.optimize import linprog
from b12.geometry import HalfPlane, intersect_halfplanes


def main():
    rng = random.Random(611209)
    counts = {"empty": 0, "unbounded": 0, "bounded": 0}
    for case in range(500):
        planes = [HalfPlane(rng.uniform(-1, 1), rng.uniform(-1, 1), rng.uniform(-100, 100)).normalized()
                  for _ in range(rng.randint(2, 12))]
        matrix = [[p.a, p.b] for p in planes]
        limits = [p.c for p in planes]
        feasibility = linprog([0, 0], A_ub=matrix, b_ub=limits, bounds=[(None, None)] * 2, method="highs")
        actual = intersect_halfplanes(planes)
        if feasibility.status == 2:
            expected = "empty"
        elif feasibility.status == 0:
            supports = [linprog(c, A_ub=matrix, b_ub=limits, bounds=[(None, None)] * 2, method="highs")
                        for c in ([1, 0], [-1, 0], [0, 1], [0, -1])]
            expected = "unbounded" if any(result.status == 3 for result in supports) else "bounded"
            if expected == "bounded":
                if actual.status not in ("point", "segment", "polygon"):
                    raise AssertionError((case, "expected bounded", actual))
                for c, reference in zip(([1, 0], [-1, 0], [0, 1], [0, -1]), supports):
                    if reference.status != 0:
                        raise AssertionError((case, reference.message))
                    ours = min(c[0] * p[0] + c[1] * p[1] for p in actual.vertices)
                    if abs(ours - reference.fun) > 1e-6 * max(1, abs(reference.fun)):
                        raise AssertionError((case, ours, reference.fun))
        else:
            raise AssertionError((case, feasibility.message))
        actual_category = actual.status if actual.status in ("empty", "unbounded") else "bounded"
        if actual_category != expected:
            raise AssertionError((case, expected, actual_category))
        counts[expected] += 1
    result = {"reference": "scipy.optimize.linprog, HiGHS", "seed": 611209,
              "random_halfplane_systems": 500, "classification_counts": counts,
              "classification_mismatches": 0, "bounded_coordinate_support_mismatches": 0}
    (ROOT / "results").mkdir(exist_ok=True)
    (ROOT / "results/reference_validation.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

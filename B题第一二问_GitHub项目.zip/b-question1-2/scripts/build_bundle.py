"""仅收集明确列出的交付文件，输出到本项目 dist/，不访问 GitHub。"""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PREFIX = "b-question1-2"
FIXED_TIME = (2026, 9, 10, 0, 0, 0)


def deliverables() -> list[Path]:
    files = [ROOT / p for p in (".gitignore", ".gitattributes", "README.md", "pyproject.toml")]
    allowed = {
        "b12": {".py"}, "tests": {".py"}, "examples": {".json"},
        "scripts": {".py"}, "docs": {".md", ".svg", ".png"},
        "results": {".json", ".csv"},
    }
    for directory, extensions in allowed.items():
        for path in (ROOT / directory).rglob("*"):
            relative = path.relative_to(ROOT)
            if "local" in relative.parts or "__pycache__" in relative.parts:
                continue
            if path.is_file() and path.suffix.lower() in extensions:
                if not path.resolve().is_relative_to(ROOT):
                    raise ValueError(f"拒绝打包指向项目外的文件：{relative}")
                files.append(path)
    for path in files:
        if not path.is_file():
            raise FileNotFoundError(path)
    return sorted(files, key=lambda p: p.relative_to(ROOT).as_posix())


def zip_write(archive, name: str, content: bytes):
    info = zipfile.ZipInfo(name, FIXED_TIME)
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = 0o100644 << 16
    archive.writestr(info, content)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--verify", action="store_true", help="在项目内临时解压并运行已打包的测试和命令")
    args = parser.parse_args()
    files = deliverables()
    # 对实际将交付的源码和相对链接做检查，不依赖未打包的原始材料。
    for path in files:
        if path.suffix == ".py":
            ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        if path.suffix == ".md":
            content = path.read_text(encoding="utf-8")
            if content.count("$$") % 2:
                raise AssertionError("显示公式分隔符不成对：" + str(path))
            for target in re.findall(r"\[[^\]]*\]\(([^)]+)\)", content):
                if "://" in target or target.startswith("#"):
                    continue
                linked = (path.parent / target.split("#", 1)[0]).resolve()
                if not linked.is_relative_to(ROOT) or not linked.exists():
                    raise AssertionError("文档相对链接失效：" + target)
                if linked.is_file() and linked not in files:
                    raise AssertionError("文档引用了未打包文件：" + target)
    output = ROOT / "dist"
    output.mkdir(exist_ok=True)
    zip_path = output / "B题第一二问_GitHub项目.zip"
    manifest = []
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in files:
            content = path.read_bytes()
            relative = path.relative_to(ROOT).as_posix()
            manifest.append(hashlib.sha256(content).hexdigest() + "  " + relative)
            zip_write(archive, PREFIX + "/" + relative, content)
        zip_write(archive, PREFIX + "/MANIFEST.sha256", ("\n".join(manifest) + "\n").encode("utf-8"))
    with zipfile.ZipFile(zip_path) as archive:
        if archive.testzip() is not None:
            raise AssertionError("ZIP CRC 校验失败")
        names = archive.namelist()
        if any("/.cache/" in name or "/Jammers-simulator/" in name or "/B题/" in name for name in names):
            raise AssertionError("压缩包中出现被排除的材料")
        if args.verify:
            cache = ROOT / ".cache"
            cache.mkdir(exist_ok=True)
            temporary = Path(tempfile.mkdtemp(prefix="package-check-", dir=cache)).resolve()
            if temporary.parent != cache.resolve() or not temporary.is_relative_to(ROOT):
                raise AssertionError("临时解压路径不在项目缓存目录内")
            try:
                for name in names:
                    if not (temporary / name).resolve().is_relative_to(temporary):
                        raise AssertionError("ZIP 成员路径越界")
                archive.extractall(temporary)
                project = temporary / PREFIX
                for line in (project / "MANIFEST.sha256").read_text(encoding="utf-8").splitlines():
                    digest, relative = line.split("  ", 1)
                    if hashlib.sha256((project / relative).read_bytes()).hexdigest() != digest:
                        raise AssertionError("成员 SHA-256 不匹配：" + relative)
                subprocess.run([sys.executable, "-B", "-X", "utf8", "-m", "unittest",
                                "discover", "-s", "tests", "-v"], cwd=project, check=True)
                result = subprocess.run([sys.executable, "-B", "-X", "utf8", "-m", "b12",
                                         "q1", "examples/q1_triangle.json"], cwd=project,
                                        check=True, capture_output=True, text=True, encoding="utf-8")
                if json.loads(result.stdout)["diameter_circle_covers"] is not False:
                    raise AssertionError("打包后的第一问命令结果不正确")
                result2 = subprocess.run([sys.executable, "-B", "-X", "utf8", "-m", "b12",
                                          "q2", "examples/q2_origin.json", "--quick", "--angle-step", "2"],
                                         cwd=project, check=True, capture_output=True,
                                         text=True, encoding="utf-8")
                if not json.loads(result2.stdout)["signal_guaranteed_by_candidate_region"]:
                    raise AssertionError("打包后的第二问命令结果不正确")
            finally:
                # 仅删除本次创建、且已确认位于项目缓存目录中的临时目录。
                if temporary.parent == cache.resolve() and temporary.is_relative_to(ROOT):
                    shutil.rmtree(temporary)
    digest = hashlib.sha256(zip_path.read_bytes()).hexdigest()
    (output / "B题第一二问_GitHub项目.sha256").write_text(digest + "  " + zip_path.name + "\n", encoding="utf-8")
    print(json.dumps({"archive": str(zip_path), "files": len(files) + 1,
                      "bytes": zip_path.stat().st_size, "sha256": digest,
                      "extracted_verification": args.verify}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

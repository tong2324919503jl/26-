"""Frozen P4 research candidate; complete discovery remains mandatory."""
from experiments_v5.p4_discovery_route_combo import SearchPolicy as ParentPolicy


class SearchPolicy(ParentPolicy):
    algorithm_version='problem4_v5_visibility_discovery'
